import { estimateTokenCount, sliceByTokens } from 'tokenx'
import { z } from 'zod'

import { getEffectiveOptionsSchema, resolveCommandOptions } from './CommandOptions.js'
import * as Completions from './Completions.js'
import type { FieldError } from './Errors.js'
import { IncurError, ValidationError } from './Errors.js'
import * as Fetch from './Fetch.js'
import * as Filter from './Filter.js'
import * as Formatter from './Formatter.js'
import * as Help from './Help.js'
import * as GeneratedMount from './internal/generated/Mount.js'
import { detectRunner } from './internal/pm.js'
import type { OneOf } from './internal/types.js'
import * as Mcp from './Mcp.js'
import type { Context as MiddlewareContext, Handler as MiddlewareHandler } from './middleware.js'
import * as Openapi from './Openapi.js'
export type { MiddlewareHandler }
import * as Parser from './Parser.js'
import type { Plugin } from './Plugin.js'
import type { Register } from './Register.js'
import * as Sanitize from './Sanitize.js'
import * as Schema from './Schema.js'
import * as Skill from './Skill.js'
import * as SyncMcp from './SyncMcp.js'
import * as SyncSkills from './SyncSkills.js'

/** A CLI application instance. Also used as a command group when mounted on a parent CLI. */
export type Cli<
  commands extends CommandsMap = {},
  vars extends z.ZodObject<any> | undefined = undefined,
  env extends z.ZodObject<any> | undefined = undefined,
> = {
  /** Registers a root command or mounts a sub-CLI as a command group. */
  command: {
    /** Registers a command. Returns the CLI instance for chaining. */
    <
      const name extends string,
      const args extends z.ZodObject<any> | undefined = undefined,
      const cmdEnv extends z.ZodObject<any> | undefined = undefined,
      const options extends z.ZodObject<any> | undefined = undefined,
      const output extends z.ZodType | undefined = undefined,
    >(
      name: name,
      definition: CommandDefinition<args, cmdEnv, options, output, vars, env>,
    ): Cli<
      commands & { [key in name]: { args: InferOutput<args>; options: InferOutput<options> } },
      vars,
      env
    >
    /** Mounts a sub-CLI as a command group. */
    <const name extends string, const sub extends CommandsMap>(
      cli: Cli<sub, any, any> & { name: name },
    ): Cli<commands & { [key in keyof sub & string as `${name} ${key}`]: sub[key] }, vars, env>
    /** Mounts a root CLI as a single command. */
    <
      const name extends string,
      const args extends z.ZodObject<any> | undefined,
      const opts extends z.ZodObject<any> | undefined,
    >(
      cli: Root<args, opts> & { name: name },
    ): Cli<
      commands & { [key in name]: { args: InferOutput<args>; options: InferOutput<opts> } },
      vars,
      env
    >
    /** Mounts a fetch handler as a command, optionally with OpenAPI spec for typed subcommands. */
    <const name extends string>(
      name: name,
      definition: {
        basePath?: string | undefined
        description?: string | undefined
        fetch: FetchHandler
        openapi?: Openapi.OpenAPISpec | undefined
        outputPolicy?: OutputPolicy | undefined
      },
    ): Cli<commands, vars, env>
  }
  /** A short description of the CLI. */
  description?: string | undefined
  /** The env schema, if declared. Use `typeof cli.env` with `middleware<vars, env>()` for typed middleware. */
  env: env
  /** The name of the CLI application. */
  name: string
  /** Handles an incoming HTTP request, resolves the matching command, and returns a JSON Response. */
  fetch(req: Request): Promise<Response>
  /** Parses argv, runs the matched command, and writes the output envelope to stdout. */
  serve(argv?: string[], options?: serve.Options): Promise<void>
  /** Mounts a generator-style plugin as a command group. */
  plugin: <
    const name extends string,
    const config extends z.ZodObject<any> | undefined = undefined,
    const sub extends CommandsMap = {},
  >(
    name: name,
    plugin: Plugin<config, sub>,
  ) => Cli<commands & { [key in keyof sub & string as `${name} ${key}`]: sub[key] }, vars, env>
  /** Registers middleware that runs around every command. */
  use(handler: MiddlewareHandler<vars, env>): Cli<commands, vars, env>
  /** The vars schema, if declared. Use `typeof cli.vars` with `middleware<vars, env>()` for typed middleware. */
  vars: vars
}

/** Root CLI — a single command with no subcommands. Carries phantom generics for mounting inference. */
export type Root<
  _args extends z.ZodObject<any> | undefined = undefined,
  _options extends z.ZodObject<any> | undefined = undefined,
> = Omit<Cli, 'command'>

/** Extracts the commands map from the registered type. */
export type Commands = Register extends { commands: infer commands extends CommandsMap }
  ? commands
  : {}

/** Call to action. */
export type Cta<commands extends CommandsMap = Commands> =
  | ([keyof commands] extends [never] ? string : (keyof commands & string) | (string & {}))
  | ([keyof commands] extends [never]
      ? {
          /** Positional arguments appended as bare values. */
          args?: Record<string, unknown> | undefined
          /** The command name to run. */
          command: string
          /** A short description of what the command does. */
          description?: string | undefined
          /** Named options formatted as `--key value` flags. */
          options?: Record<string, unknown> | undefined
        }
      :
          | {
              [name in keyof commands & string]: {
                /** Positional arguments appended as bare values. */
                args?:
                  | { [key in keyof commands[name]['args']]?: commands[name]['args'][key] | true }
                  | undefined
                /** The command name to run. */
                command: name
                /** A short description of what the command does. */
                description?: string | undefined
                /** Named options formatted as `--key value` flags. */
                options?:
                  | {
                      [key in keyof commands[name]['options']]?:
                        | commands[name]['options'][key]
                        | true
                    }
                  | undefined
              }
            }[keyof commands & string]
          | {
              /** The command name to run. */
              command: string & {}
              /** A short description of what the command does. */
              description?: string | undefined
            })

/** Creates a CLI with a root handler. Can still register subcommands which take precedence. */
export function create<
  const args extends z.ZodObject<any> | undefined = undefined,
  const env extends z.ZodObject<any> | undefined = undefined,
  const opts extends z.ZodObject<any> | undefined = undefined,
  const output extends z.ZodType | undefined = undefined,
  const vars extends z.ZodObject<any> | undefined = undefined,
>(
  name: string,
  definition: create.Options<args, env, opts, output, vars> & { run: Function },
): Cli<{ [key in typeof name]: { args: InferOutput<args>; options: InferOutput<opts> } }, vars, env>
/** Creates a router CLI that registers subcommands. */
export function create<
  const args extends z.ZodObject<any> | undefined = undefined,
  const env extends z.ZodObject<any> | undefined = undefined,
  const opts extends z.ZodObject<any> | undefined = undefined,
  const output extends z.ZodType | undefined = undefined,
  const vars extends z.ZodObject<any> | undefined = undefined,
>(name: string, definition?: create.Options<args, env, opts, output, vars>): Cli<{}, vars, env>
/** Creates a CLI with a root handler from a single options object. Can still register subcommands. */
export function create<
  const args extends z.ZodObject<any> | undefined = undefined,
  const env extends z.ZodObject<any> | undefined = undefined,
  const opts extends z.ZodObject<any> | undefined = undefined,
  const output extends z.ZodType | undefined = undefined,
  const vars extends z.ZodObject<any> | undefined = undefined,
>(
  definition: create.Options<args, env, opts, output, vars> & { name: string; run: Function },
): Cli<
  {
    [key in (typeof definition)['name']]: { args: InferOutput<args>; options: InferOutput<opts> }
  },
  vars,
  env
>
/** Creates a router CLI from a single options object (e.g. package.json). */
export function create<
  const args extends z.ZodObject<any> | undefined = undefined,
  const env extends z.ZodObject<any> | undefined = undefined,
  const opts extends z.ZodObject<any> | undefined = undefined,
  const output extends z.ZodType | undefined = undefined,
  const vars extends z.ZodObject<any> | undefined = undefined,
>(definition: create.Options<args, env, opts, output, vars> & { name: string }): Cli<{}, vars, env>
export function create(
  nameOrDefinition: string | (any & { name: string }),
  definition?: any,
): Cli | Root {
  const name = typeof nameOrDefinition === 'string' ? nameOrDefinition : nameOrDefinition.name
  const def = typeof nameOrDefinition === 'string' ? (definition ?? {}) : nameOrDefinition
  const rootDef = 'run' in def ? (def as CommandDefinition<any, any, any>) : undefined
  const rootFetch = 'fetch' in def ? (def.fetch as FetchHandler) : undefined

  const commands = new Map<string, CommandEntry>()
  const middlewares: MiddlewareHandler[] = []
  const pending: Promise<void>[] = []
  const mcpHandler = createMcpHttpHandler(name, def.version ?? '0.0.0', def.sanitize)

  function mountGeneratedGroup(
    mount: string,
    options: {
      description?: string | undefined
      kind: 'command' | 'openapi' | 'plugin'
      load: () => Promise<InternalGroup>
    },
  ) {
    pending.push(
      Promise.resolve()
        .then(options.load)
        .then((group) => {
          commands.set(mount, group)
        })
        .catch((error) => {
          const base =
            error instanceof IncurError
              ? error
              : new IncurError({
                  code:
                    options.kind === 'plugin'
                      ? 'PLUGIN_RESOLUTION_FAILED'
                      : 'COMMAND_GENERATION_FAILED',
                  message:
                    options.kind === 'plugin'
                      ? `Failed to resolve plugin '${mount}': ${error instanceof Error ? error.message : String(error)}`
                      : options.kind === 'command'
                        ? `Failed to mount command group '${mount}': ${error instanceof Error ? error.message : String(error)}`
                      : `Failed to generate command group '${mount}': ${error instanceof Error ? error.message : String(error)}`,
                })
          throw base
        }),
    )
  }

  async function awaitCliPending(sub: Cli) {
    const childPending = toPending.get(sub)
    if (childPending && childPending.length > 0) await Promise.all(childPending)
  }

  function resolveMountedGroup(sub: Cli, description = sub.description): InternalGroup {
    const subCommands = toCommands.get(sub)
    if (!subCommands)
      throw new IncurError({
        code: 'COMMAND_GENERATION_FAILED',
        message: `Mounted CLI '${sub.name}' is not ready`,
      })
    const subOutputPolicy = toOutputPolicy.get(sub)
    const subMiddlewares = toMiddlewares.get(sub)
    return GeneratedMount.toInternalGroup({
      commands: subCommands,
      description,
      middlewares: subMiddlewares,
      outputPolicy: subOutputPolicy,
    })
  }

  const cli: Cli = {
    name,
    description: def.description,
    env: def.env,
    vars: def.vars,

    command(nameOrCli: any, def?: any): any {
      if (typeof nameOrCli === 'string') {
        if (def && 'fetch' in def && typeof def.fetch === 'function') {
          if (def.openapi) {
            mountGeneratedGroup(nameOrCli, {
              description: def.description,
              kind: 'openapi',
              load: async () => ({
                _group: true,
                description: def.description,
                commands: (await Openapi.generateCommands(def.openapi, def.fetch, {
                  basePath: def.basePath,
                })) as Map<string, CommandEntry>,
                ...(def.outputPolicy ? { outputPolicy: def.outputPolicy } : undefined),
              }),
            })
            return cli
          }
          commands.set(nameOrCli, {
            _fetch: true,
            basePath: def.basePath,
            description: def.description,
            fetch: def.fetch,
            ...(def.outputPolicy ? { outputPolicy: def.outputPolicy } : undefined),
          } as InternalFetchGateway)
          return cli
        }
        commands.set(nameOrCli, def)
        return cli
      }
      const mountedRootDef = toRootDefinition.get(nameOrCli)
      if (mountedRootDef) {
        commands.set(nameOrCli.name, mountedRootDef)
        return cli
      }
      const sub = nameOrCli as Cli
      const childPending = toPending.get(sub)
      if (childPending && childPending.length > 0)
        mountGeneratedGroup(sub.name, {
          description: sub.description,
          kind: 'command',
          load: async () => {
            await awaitCliPending(sub)
            return resolveMountedGroup(sub)
          },
        })
      else commands.set(sub.name, resolveMountedGroup(sub))
      return cli
    },

    plugin(nameOrCli: any, plugin: any): any {
      mountGeneratedGroup(nameOrCli, {
        description: plugin.description,
        kind: 'plugin',
        load: async () => {
          const config =
            plugin.config instanceof z.ZodObject
              ? plugin.config.parse(plugin.options ?? {})
              : undefined
          const resolved = await plugin.resolve({
            mount: nameOrCli,
            cwd: process.cwd(),
            config,
          })
          if (resolved.name !== nameOrCli)
            throw new IncurError({
              code: 'PLUGIN_RESOLUTION_FAILED',
              message: `Plugin '${plugin.name}' resolved '${resolved.name}', expected '${nameOrCli}'`,
            })
          await awaitCliPending(resolved)
          return resolveMountedGroup(resolved, plugin.description ?? resolved.description)
        },
      })
      return cli
    },

    async fetch(req: Request) {
      try {
        if (pending.length > 0) await Promise.all(pending)
      } catch (error) {
        return renderPendingFetchError(name, error)
      }
      return fetchImpl(name, commands, req, {
        envSchema: def.env,
        mcpHandler,
        middlewares,
        rootCommand: rootDef,
        sanitize: def.sanitize,
        vars: def.vars,
        version: def.version,
      })
    },

    async serve(argv = process.argv.slice(2), serveOptions: serve.Options = {}) {
      try {
        if (pending.length > 0) await Promise.all(pending)
      } catch (error) {
        return renderPendingServeError(name, argv, error, serveOptions)
      }
      return serveImpl(name, commands, argv, {
        ...serveOptions,
        aliases: def.aliases,
        description: def.description,
        envSchema: def.env,
        format: def.format,
        contextRules: def.contextRules,
        mcp: def.mcp,
        middlewares,
        outputPolicy: def.outputPolicy,
        rootCommand: rootDef,
        rootFetch,
        sanitize: def.sanitize,
        sync: def.sync,
        vars: def.vars,
        version: def.version,
      })
    },

    use(handler: MiddlewareHandler): any {
      middlewares.push(handler)
      return cli
    },
  }

  if (rootDef) toRootDefinition.set(cli as unknown as Root, rootDef)
  if (def.outputPolicy) toOutputPolicy.set(cli, def.outputPolicy)
  toMiddlewares.set(cli, middlewares)
  toPending.set(cli, pending)
  toCommands.set(cli, commands)
  return cli
}

export declare namespace create {
  /** Options for creating a CLI. Provide `run` for a leaf CLI, omit it for a router. */
  type Options<
    args extends z.ZodObject<any> | undefined = undefined,
    env extends z.ZodObject<any> | undefined = undefined,
    options extends z.ZodObject<any> | undefined = undefined,
    output extends z.ZodType | undefined = undefined,
    vars extends z.ZodObject<any> | undefined = undefined,
  > = {
    /** Map of option names to single-char aliases. */
    alias?: options extends z.ZodObject<any>
      ? Partial<Record<keyof z.output<options>, string>>
      : Record<string, string> | undefined
    /** Alternative binary names for this CLI (e.g. shorter aliases in package.json `bin`). Shell completions are registered for all names. */
    aliases?: string[] | undefined
    /** Zod schema for positional arguments. */
    args?: args | undefined
    /** A short description of what the CLI does. */
    description?: string | undefined
    /** Zod schema for environment variables. Keys are the variable names (e.g. `NPM_TOKEN`). */
    env?: env | undefined
    /** Usage examples for this command. */
    examples?: Example<args, options>[] | undefined
    /** A fetch handler to use as the root command. All argv tokens are interpreted as path segments and curl-style flags. */
    fetch?: FetchHandler | undefined
    /** Default output format. Overridden by `--format` or `--json`. */
    format?: Formatter.Format | undefined
    /** Rules that should be written into generated agent context. */
    contextRules?: string[] | undefined
    /** Validates a full JSON payload passed via `--json`. */
    input?: z.ZodObject<any> | undefined
    /** Whether this command mutates external state. */
    mutates?: boolean | undefined
    /** Whether this command is destructive and requires confirmation. */
    destructive?: boolean | undefined
    /** Whether this command supports pagination helpers. */
    paginate?: boolean | undefined
    /** Zod schema for named options/flags. */
    options?: options | undefined
    /** Validates a request body passed via `--json`. */
    body?: z.ZodObject<any> | undefined
    /** Zod schema for the return value. */
    output?: output | undefined
    /** Sanitizes output before formatting when the consumer is an agent. */
    sanitize?:
      | ((
          output: unknown,
          context: { command: string; agent: boolean },
        ) => Promise<{
          output: unknown
          blocked: boolean
          warnings?: string[] | undefined
        }>)
      | undefined
    /**
     * Controls when output data is displayed. Inherited by child commands when set on a group or root CLI.
     *
     * - `'all'` — displays to both humans and agents.
     * - `'agent-only'` — suppresses data output in human/TTY mode while still returning it to agents.
     *
     * @default 'all'
     */
    outputPolicy?: OutputPolicy | undefined
    /** Alternative usage patterns shown in help output. */
    usage?: Usage<args, options>[] | undefined
    /** Zod schema for middleware variables. Keys define variable names, schemas define types and defaults. */
    vars?: vars | undefined
    /** The root command handler. When provided, creates a leaf CLI with no subcommands. */
    run?:
      | ((context: {
          /** Whether the consumer is an agent (stdout is not a TTY). */
          agent: boolean
          /** Positional arguments. */
          args: InferOutput<args>
          /** The CLI name. */
          name: string
          /** Whether this invocation is a dry-run preflight. */
          dryRun: boolean
          /** Parsed environment variables. */
          env: InferOutput<env>
          /** Return an error result with optional CTAs. */
          error: (options: {
            code: string
            cta?: CtaBlock | undefined
            exitCode?: number | undefined
            message: string
            retryable?: boolean | undefined
          }) => never
          /** The resolved output format (e.g. `'toon'`, `'json'`, `'jsonl'`). */
          format: Formatter.Format
          /** Whether the user explicitly passed `--format` or `--json`. */
          formatExplicit: boolean
          /** Return a success result with optional metadata (e.g. CTAs). */
          ok: (data: InferReturn<output>, meta?: { cta?: CtaBlock | undefined }) => never
          options: InferOutput<options>
          /** Variables set by middleware. */
          var: InferVars<vars>
        }) =>
          | InferReturn<output>
          | Promise<InferReturn<output>>
          | AsyncGenerator<InferReturn<output>, unknown, unknown>)
      | undefined
    /** Options for the built-in `mcp add` command. */
    mcp?:
      | {
          /** Target specific agents by default (e.g. `['claude-code', 'cursor']`). */
          agents?: string[] | undefined
          /** Override the command agents will run to start the MCP server. Auto-detected if omitted. */
          command?: string | undefined
        }
      | undefined
    /** Options for the built-in `skills add` command. */
    sync?:
      | {
          /** Working directory for resolving `include` globs. Pass `import.meta.dirname` when running from a bin entry. Defaults to `process.cwd()`. */
          cwd?: string | undefined
          /** Default grouping depth for skill files. Overridden by `--depth`. Defaults to `1`. */
          depth?: number | undefined
          /** Glob patterns for directories containing SKILL.md files to include (e.g. `"skills/*"`, `"my-skill"`). */
          include?: string[] | undefined
          /** Example prompts shown after sync to help users get started. */
          suggestions?: string[] | undefined
        }
      | undefined
    /** The CLI version string. */
    version?: string | undefined
  }
}

export declare namespace serve {
  /** Options for `serve()`, primarily used for testing. */
  type Options = {
    /** Override environment variable source. Defaults to `process.env`. */
    env?: Record<string, string | undefined> | undefined
    /** Override exit handler. Defaults to `process.exit`. */
    exit?: ((code: number) => void) | undefined
    /** Override stdout writer. Defaults to `process.stdout.write`. */
    stdout?: ((s: string) => void) | undefined
  }
}

function toStartupError(error: unknown) {
  if (error instanceof IncurError) return error
  return new IncurError({
    code: 'UNKNOWN',
    cause: error instanceof Error ? error : undefined,
    message: error instanceof Error ? error.message : String(error),
  })
}

async function renderPendingServeError(
  _name: string,
  argv: string[],
  error: unknown,
  options: serve.Options = {},
) {
  const failure = toStartupError(error)
  const stdout = options.stdout ?? ((s: string) => process.stdout.write(s))
  const exit = options.exit ?? ((code: number) => process.exit(code))
  const { format: formatFlag, formatExplicit } = extractBuiltinFlags(argv)
  const human = process.stdout.isTTY === true
  const payload = {
    code: failure.code,
    message: failure.message,
    ...(failure.retryable !== undefined ? { retryable: failure.retryable } : undefined),
  }
  if (human && !formatExplicit) stdout(`${formatHumanError(payload)}\n`)
  else stdout(`${Formatter.format(payload, formatFlag)}\n`)
  exit(failure.exitCode ?? 1)
}

function renderPendingFetchError(name: string, error: unknown) {
  const failure = toStartupError(error)
  return new Response(
    JSON.stringify({
      ok: false,
      error: {
        code: failure.code,
        message: failure.message,
        ...(failure.retryable !== undefined ? { retryable: failure.retryable } : undefined),
      },
      meta: {
        command: name,
        duration: '0ms',
      },
    }),
    {
      headers: { 'content-type': 'application/json' },
      status: 500,
    },
  )
}

/** @internal Shared serve implementation for both router and leaf CLIs. */
// biome-ignore lint/correctness/noUnusedVariables: _
async function serveImpl(
  name: string,
  commands: Map<string, CommandEntry>,
  argv: string[],
  options: serveImpl.Options = {},
) {
  const stdout = options.stdout ?? ((s: string) => process.stdout.write(s))
  const exit = options.exit ?? ((code: number) => process.exit(code))

  const {
    verbose,
    format: formatFlag,
    formatExplicit,
    filterOutput,
    tokenLimit,
    tokenOffset,
    tokenCount,
    llms,
    llmsFull,
    mcp: mcpFlag,
    help,
    version,
    schema,
    rest: filtered,
  } = extractBuiltinFlags(argv)

  // --mcp: start as MCP stdio server
  if (mcpFlag) {
    try {
      await Mcp.serve(name, options.version ?? '0.0.0', commands, { sanitize: options.sanitize })
    } catch (error) {
      return renderPendingServeError(name, argv, error, { stdout, exit })
    }
    return
  }

  // COMPLETE: dynamic shell completions (called by shell hook at tab-press)
  const completeShell = process.env.COMPLETE as Completions.Shell | undefined
  if (completeShell) {
    // Remove separator `--` from argv
    const sepIdx = argv.indexOf('--')
    const words = sepIdx !== -1 ? argv.slice(sepIdx + 1) : argv
    if (words.length === 0) {
      // Registration mode: print shell hook script for primary name + aliases
      const names = [name, ...(options.aliases ?? [])]
      stdout(names.map((n) => Completions.register(completeShell, n)).join('\n'))
    } else {
      const index = Number(process.env._COMPLETE_INDEX ?? words.length - 1)
      const candidates = Completions.complete(commands, options.rootCommand, words, index)
      const out = Completions.format(completeShell, candidates)
      if (out) stdout(out)
    }
    return
  }

  // Human mode: stdout is a TTY.
  const human = process.stdout.isTTY === true

  function writeln(s: string) {
    stdout(s.endsWith('\n') ? s : `${s}\n`)
  }

  // Skills staleness check (skip for built-in commands)
  if (!llms && !llmsFull && !schema && !help && !version) {
    const isSkillsAdd =
      filtered[0] === 'skills' || (filtered[0] === name && filtered[1] === 'skills')
    const isMcpAdd = filtered[0] === 'mcp' || (filtered[0] === name && filtered[1] === 'mcp')
    if (!isSkillsAdd && !isMcpAdd) {
      const stored = SyncSkills.readHash(name)
      if (stored) {
        const groups = new Map<string, string>()
        const entries = collectSkillCommands(commands, [], groups)
        if (Skill.hash(entries) !== stored) {
          const runner = detectRunner()
          const spec = SyncMcp.detectPackageSpecifier(name)
          process.stderr.write(
            `⚠ Skills are out of date. Run '${runner} ${spec} skills add' to update.\n\n`,
          )
        }
      }
    }
  }

  if (llms || llmsFull) {
    // Scope to a subtree if command tokens are provided
    let scopedCommands = commands
    const prefix: string[] = []
    let scopedDescription: string | undefined = options.description
    for (const token of filtered) {
      const entry = scopedCommands.get(token)
      if (!entry) break
      if (isGroup(entry)) {
        scopedCommands = entry.commands
        scopedDescription = entry.description
        prefix.push(token)
      } else {
        // Leaf command — scope to just this command
        scopedCommands = new Map([[token, entry]])
        break
      }
    }

    if (llmsFull) {
      if (!formatExplicit || formatFlag === 'md') {
        const groups = new Map<string, string>()
        const cmds = collectSkillCommands(scopedCommands, prefix, groups)
        const scopedName = prefix.length > 0 ? `${name} ${prefix.join(' ')}` : name
        writeln(Skill.generate(scopedName, cmds, groups))
        return
      }
      writeln(Formatter.format(buildManifest(scopedCommands, prefix), formatFlag))
      return
    }

    if (!formatExplicit || formatFlag === 'md') {
      const groups = new Map<string, string>()
      const cmds = collectSkillCommands(scopedCommands, prefix, groups)
      const scopedName = prefix.length > 0 ? `${name} ${prefix.join(' ')}` : name
      writeln(Skill.index(scopedName, cmds, scopedDescription))
      return
    }
    writeln(Formatter.format(buildIndexManifest(scopedCommands, prefix), formatFlag))
    return
  }

  const schemaIdx =
    filtered[0] === 'schema' ? 0 : filtered[0] === name && filtered[1] === 'schema' ? 1 : -1
  if (schemaIdx !== -1) {
    const tokens = filtered.slice(schemaIdx + 1)
    if (tokens.length === 0) {
      writeln(
        Formatter.format(
          {
            code: 'SCHEMA_COMMAND_REQUIRED',
            message: `Usage: ${name} schema <command>`,
          },
          formatExplicit ? formatFlag : 'toon',
        ),
      )
      exit(1)
      return
    }

    const resolvedSchema = resolveCommand(commands, tokens)
    if ('command' in resolvedSchema) {
      writeln(
        Formatter.format(
          describeCommand(tokens, resolvedSchema.command),
          formatExplicit ? formatFlag : 'toon',
        ),
      )
      return
    }

    writeln(
      Formatter.format(
        {
          code: 'SCHEMA_NOT_FOUND',
          message: `Command '${tokens.join(' ')}' was not found`,
        },
        formatExplicit ? formatFlag : 'toon',
      ),
    )
    exit(1)
    return
  }

  // completions <shell>: print shell hook script to stdout
  const completionsIdx = (() => {
    // e.g. `completions bash`
    if (filtered[0] === 'completions') return 0
    // e.g. `my-cli completions bash`
    if (filtered[0] === name && filtered[1] === 'completions') return 1
    // not a completions invocation
    return -1
  })()
  if (completionsIdx !== -1 && filtered[completionsIdx] === 'completions') {
    if (help) {
      writeln(
        [
          `${name} completions — Generate shell completion script`,
          '',
          `Usage: ${name} completions <shell>`,
          '',
          'Shells:',
          '  bash',
          '  fish',
          '  nushell',
          '  zsh',
          '',
          'Setup:',
          ...(() => {
            const rows = [
              ['bash', `eval "$(${name} completions bash)"`, '# add to ~/.bashrc'],
              ['zsh', `eval "$(${name} completions zsh)"`, '# add to ~/.zshrc'],
              ['fish', `${name} completions fish | source`, '# add to ~/.config/fish/config.fish'],
              ['nushell', `see \`${name} completions nushell\``, '# add to config.nu'],
            ]
            const shellW = Math.max(...rows.map((r) => r[0]!.length))
            const cmdW = Math.max(...rows.map((r) => r[1]!.length))
            return rows.map(
              ([shell, cmd, comment]) =>
                `  ${shell!.padEnd(shellW)}  ${cmd!.padEnd(cmdW)}  ${comment}`,
            )
          })(),
        ].join('\n'),
      )
      return
    }
    const shell = filtered[completionsIdx + 1]
    if (!shell || !['bash', 'fish', 'nushell', 'zsh'].includes(shell)) {
      writeln(
        formatHumanError({
          code: 'INVALID_SHELL',
          message: shell
            ? `Unknown shell '${shell}'. Supported: bash, fish, nushell, zsh`
            : `Missing shell argument. Usage: ${name} completions <bash|fish|nushell|zsh>`,
        }),
      )
      exit(1)
      return
    }
    const names = [name, ...(options.aliases ?? [])]
    writeln(names.map((n) => Completions.register(shell as Completions.Shell, n)).join('\n'))
    return
  }

  // skills add: generate skill files and install via `<pm>x skills add` (only when sync is configured)
  const skillsIdx =
    filtered[0] === 'skills' ? 0 : filtered[0] === name && filtered[1] === 'skills' ? 1 : -1
  if (skillsIdx !== -1 && filtered[skillsIdx] === 'skills' && filtered[skillsIdx + 1] === 'add') {
    if (help) {
      writeln(
        [
          `${name} skills add — Sync skill files to your agent`,
          '',
          `Usage: ${name} skills add [options]`,
          '',
          'Options:',
          '  --depth <number>  Grouping depth for skill files (default: 1)',
          '  --no-global       Install to project instead of globally',
        ].join('\n'),
      )
      return
    }
    const rest = filtered.slice(skillsIdx + 2)
    const depthArg = rest.indexOf('--depth')
    const depthEq = rest.find((t) => t.startsWith('--depth='))
    const depth =
      depthArg !== -1
        ? Number(rest[depthArg + 1])
        : depthEq
          ? Number(depthEq.split('=')[1])
          : (options.sync?.depth ?? 1)
    const global = rest.includes('--no-global') ? false : undefined
    try {
      stdout('Syncing...')
      const result = await SyncSkills.sync(name, commands, {
        cwd: options.sync?.cwd,
        depth,
        description: options.description,
        contextRules: options.contextRules,
        global,
        include: options.sync?.include,
      })
      stdout('\r\x1b[K')
      const lines: string[] = []
      const skillLabel = (s: (typeof result.skills)[number]) =>
        s.external || s.name === name ? s.name : `${name}-${s.name}`
      const maxLen = Math.max(...result.skills.map((s) => skillLabel(s).length))
      for (const s of result.skills) {
        const label = skillLabel(s)
        const padding = s.description
          ? `${' '.repeat(maxLen - label.length)}  ${s.description}`
          : ''
        lines.push(`  ✓ ${label}${padding}`)
      }
      lines.push('')
      lines.push(`${result.skills.length} skill${result.skills.length === 1 ? '' : 's'} synced`)
      const suggestions = options.sync?.suggestions
      if (suggestions && suggestions.length > 0) {
        lines.push('')
        lines.push(`Your agent can now use ${name}. Try asking:`)
        for (const s of suggestions) lines.push(`  "${s}"`)
      }
      lines.push('')
      lines.push(`Run \`${name} --help\` to see the full command reference.`)
      writeln(lines.join('\n'))
      if (verbose || formatExplicit) {
        const output: Record<string, unknown> = { skills: result.paths }
        if (verbose && result.agents.length > 0) output.agents = result.agents
        writeln(Formatter.format(output, formatExplicit ? formatFlag : 'toon'))
      }
    } catch (err) {
      writeln(
        Formatter.format(
          { code: 'SYNC_SKILLS_FAILED', message: err instanceof Error ? err.message : String(err) },
          formatExplicit ? formatFlag : 'toon',
        ),
      )
      exit(1)
    }
    return
  }

  // mcp add: register CLI as MCP server via `npx add-mcp`
  const mcpIdx = filtered[0] === 'mcp' ? 0 : filtered[0] === name && filtered[1] === 'mcp' ? 1 : -1
  if (mcpIdx !== -1 && filtered[mcpIdx] === 'mcp' && filtered[mcpIdx + 1] === 'add') {
    if (help) {
      writeln(
        [
          `${name} mcp add — Register as an MCP server for your agent`,
          '',
          `Usage: ${name} mcp add [options]`,
          '',
          'Options:',
          '  -c, --command <cmd>  Override the command agents will run (e.g. "pnpm my-cli --mcp")',
          '  --no-global          Install to project instead of globally',
          '  --agent <agent>      Target a specific agent (e.g. claude-code, cursor)',
        ].join('\n'),
      )
      return
    }
    const rest = filtered.slice(mcpIdx + 2)
    const global = rest.includes('--no-global') ? false : true

    // Parse --command / -c and --agent flags from argv
    let command = options.mcp?.command
    const agents: string[] = [...(options.mcp?.agents ?? [])]
    for (let i = 0; i < rest.length; i++) {
      if ((rest[i] === '--command' || rest[i] === '-c') && rest[i + 1]) command = rest[++i]!
      else if (rest[i] === '--agent' && rest[i + 1]) agents.push(rest[++i]!)
    }

    try {
      stdout('Registering MCP server...')
      const result = await SyncMcp.register(name, {
        command,
        global,
        agents,
      })
      stdout('\r\x1b[K')
      const lines: string[] = []
      lines.push(`✓ Registered ${name} as MCP server`)
      if (result.agents.length > 0) lines.push(`  Agents: ${result.agents.join(', ')}`)
      lines.push('')
      lines.push(`Agents can now use ${name} tools.`)
      const suggestions = options.sync?.suggestions
      if (suggestions && suggestions.length > 0) {
        lines.push('')
        lines.push('Try asking:')
        for (const s of suggestions) lines.push(`  "${s}"`)
      }
      writeln(lines.join('\n'))
      if (verbose || formatExplicit)
        writeln(
          Formatter.format(
            { name, command: result.command, agents: result.agents },
            formatExplicit ? formatFlag : 'toon',
          ),
        )
    } catch (err) {
      writeln(
        Formatter.format(
          { code: 'MCP_ADD_FAILED', message: err instanceof Error ? err.message : String(err) },
          formatExplicit ? formatFlag : 'toon',
        ),
      )
      exit(1)
    }
    return
  }

  // --help takes precedence over --version
  if (version && !help && options.version) {
    writeln(options.version)
    return
  }

  if (filtered.length === 0) {
    if (
      options.rootCommand &&
      human &&
      options.rootCommand.args &&
      hasRequiredArgs(options.rootCommand.args)
    ) {
      // Root command with args but none provided (human mode) — show help
      const cmd = options.rootCommand
      writeln(
        Help.formatCommand(name, {
          alias: cmd.alias as Record<string, string> | undefined,
          aliases: options.aliases,
          description: cmd.description ?? options.description,
          version: options.version,
          args: cmd.args,
          env: cmd.env,
          envSource: options.env,
          hint: cmd.hint,
          options: getEffectiveOptionsSchema(cmd),
          examples: formatExamples(cmd.examples),
          usage: cmd.usage,
          commands: commands.size > 0 ? collectHelpCommands(commands) : undefined,
          root: true,
        }),
      )
      return
    }
    if (options.rootCommand || options.rootFetch) {
      // Root command/fetch with no args — treat as root invocation
    } else {
      writeln(
        Help.formatRoot(name, {
          aliases: options.aliases,
          description: options.description,
          version: options.version,
          commands: collectHelpCommands(commands),
          root: true,
        }),
      )
      return
    }
  }

  const resolved =
    filtered.length === 0 && options.rootCommand
      ? { command: options.rootCommand, path: name, rest: [] as string[] }
      : filtered.length === 0 && options.rootFetch
        ? {
            fetchGateway: {
              _fetch: true as const,
              fetch: options.rootFetch,
              description: options.description,
            },
            middlewares: [] as MiddlewareHandler[],
            path: name,
            rest: [] as string[],
          }
        : resolveCommand(commands, filtered)

  // --help on a fetch gateway → show fetch-specific help
  if (help && 'fetchGateway' in resolved) {
    const commandName = resolved.path === name ? name : `${name} ${resolved.path}`
    writeln(formatFetchHelp(commandName, resolved.fetchGateway.description))
    return
  }

  // --help after a command → show help for that command
  if (help) {
    if ('help' in resolved || 'error' in resolved) {
      // group or unknown → show root help for that path
      const helpName = 'help' in resolved ? `${name} ${resolved.path}` : name
      const helpDesc = 'help' in resolved ? resolved.description : options.description
      const helpCmds = 'help' in resolved ? resolved.commands : commands
      const isRoot = helpName === name
      // Root with both a handler and subcommands → show command help with subcommands
      if (isRoot && options.rootCommand && helpCmds.size > 0) {
        const cmd = options.rootCommand
        writeln(
          Help.formatCommand(name, {
            alias: cmd.alias as Record<string, string> | undefined,
            aliases: options.aliases,
            description: cmd.description ?? options.description,
            version: options.version,
            args: cmd.args,
            env: cmd.env,
            envSource: options.env,
            hint: cmd.hint,
            options: getEffectiveOptionsSchema(cmd),
            examples: formatExamples(cmd.examples),
            usage: cmd.usage,
            commands: collectHelpCommands(helpCmds),
            root: true,
          }),
        )
      } else {
        writeln(
          Help.formatRoot(helpName, {
            aliases: isRoot ? options.aliases : undefined,
            description: helpDesc,
            version: isRoot ? options.version : undefined,
            commands: collectHelpCommands(helpCmds),
            root: isRoot,
          }),
        )
      }
    } else if ('command' in resolved) {
      const cmd = resolved.command
      const isRootCmd = resolved.path === name
      const commandName = isRootCmd ? name : `${name} ${resolved.path}`
      const helpSubcommands =
        isRootCmd && options.rootCommand && commands.size > 0
          ? collectHelpCommands(commands)
          : undefined
      writeln(
        Help.formatCommand(commandName, {
          alias: cmd.alias as Record<string, string> | undefined,
          aliases: isRootCmd ? options.aliases : undefined,
          description: cmd.description,
          version: isRootCmd ? options.version : undefined,
          args: cmd.args,
          env: cmd.env,
          envSource: options.env,
          hint: cmd.hint,
          options: getEffectiveOptionsSchema(cmd),
          examples: formatExamples(cmd.examples),
          usage: cmd.usage,
          commands: helpSubcommands,
          root: isRootCmd,
        }),
      )
    }
    return
  }

  // --schema: output JSON Schema for a command's args, env, options, output
  if (schema) {
    if ('help' in resolved) {
      writeln(
        Help.formatRoot(`${name} ${resolved.path}`, {
          description: resolved.description,
          commands: collectHelpCommands(resolved.commands),
        }),
      )
      return
    }
    if ('error' in resolved) {
      const parent = resolved.path ? `${name} ${resolved.path}` : name
      writeln(`Error: '${resolved.error}' is not a command for '${parent}'.`)
      exit(1)
      return
    }
    if ('fetchGateway' in resolved) {
      writeln('--schema is not supported for fetch commands.')
      exit(1)
      return
    }
    const cmd = resolved.command
    const format = formatExplicit ? formatFlag : 'toon'
    const result: Record<string, unknown> = {}
    if (cmd.args) result.args = Schema.toJsonSchema(cmd.args)
    if (cmd.env) result.env = Schema.toJsonSchema(cmd.env)
    if (cmd.options) result.options = Schema.toJsonSchema(cmd.options)
    if (cmd.output) result.output = Schema.toJsonSchema(cmd.output)
    writeln(Formatter.format(result, format))
    return
  }

  if ('help' in resolved) {
    writeln(
      Help.formatRoot(`${name} ${resolved.path}`, {
        description: resolved.description,
        commands: collectHelpCommands(resolved.commands),
      }),
    )
    return
  }

  const start = performance.now()

  // Resolve effective format: explicit --format/--json → command default → CLI default → toon
  const resolvedFormat = 'command' in resolved && (resolved as any).command.format
  const format = formatExplicit ? formatFlag : resolvedFormat || options.format || 'toon'

  // Fall back to root fetch when no subcommand matches
  const effective =
    'error' in resolved && options.rootFetch && !resolved.path
      ? {
          fetchGateway: {
            _fetch: true as const,
            fetch: options.rootFetch,
            description: options.description,
          },
          middlewares: [] as MiddlewareHandler[],
          path: name,
          rest: filtered,
        }
      : 'error' in resolved && options.rootCommand && !resolved.path
        ? { command: options.rootCommand, path: name, rest: filtered }
        : resolved

  // Resolve outputPolicy: command/group → CLI-level → default ('all')
  const effectiveOutputPolicy =
    ('outputPolicy' in resolved && resolved.outputPolicy) || options.outputPolicy
  const renderOutput = !(human && !formatExplicit && effectiveOutputPolicy === 'agent-only')

  const filterPaths = filterOutput ? Filter.parse(filterOutput) : undefined

  function truncate(s: string): {
    text: string
    truncated: boolean
    nextOffset?: number | undefined
  } {
    if (tokenLimit == null && tokenOffset == null) return { text: s, truncated: false }
    const total = estimateTokenCount(s)
    const offset = tokenOffset ?? 0
    const end = tokenLimit != null ? offset + tokenLimit : total
    if (offset === 0 && end >= total) return { text: s, truncated: false }
    const sliced = sliceByTokens(s, offset, end)
    const actualEnd = Math.min(end, total)
    const nextOffset = actualEnd < total ? actualEnd : undefined
    return {
      text: `${sliced}\n[truncated: showing tokens ${offset}–${actualEnd} of ${total}]`,
      truncated: true,
      nextOffset,
    }
  }

  function withWarnings(base: unknown, warnings: string[] | undefined) {
    if (!warnings || warnings.length === 0) return base
    if (typeof base === 'object' && base !== null) return { ...base, _warnings: warnings }
    return { data: base, _warnings: warnings }
  }

  async function prepareOutput(
    output: Output,
    outputSchema?: z.ZodType | undefined,
  ): Promise<Output> {
    let prepared = output
    const warnings = [...(prepared.meta.warnings ?? [])]

    if (filterPaths && prepared.ok && prepared.data != null) {
      if (outputSchema) {
        const schemaWarnings = Filter.validate(filterPaths, Schema.toJsonSchema(outputSchema))
        warnings.push(...schemaWarnings)
      }
      prepared = { ...prepared, data: Filter.apply(prepared.data, filterPaths) }
    }

    const target = prepared.ok ? prepared.data : prepared.error
    const sanitized = await Sanitize.sanitize(
      target,
      { command: prepared.meta.command, agent: !human },
      options.sanitize,
    )

    if (sanitized.warnings) warnings.push(...sanitized.warnings)

    if (sanitized.blocked) {
      return {
        ok: false,
        error: {
          code: 'SANITIZED_OUTPUT_BLOCKED',
          message: 'Command output was blocked by sanitization',
          ...(warnings.length ? { warnings: [...new Set(warnings)] } : undefined),
        },
        meta: {
          ...prepared.meta,
          ...(warnings.length ? { warnings: [...new Set(warnings)] } : undefined),
        },
      }
    }

    if (prepared.ok) {
      return {
        ...prepared,
        data: sanitized.output,
        meta: {
          ...prepared.meta,
          ...(warnings.length ? { warnings: [...new Set(warnings)] } : undefined),
        },
      }
    }

    const baseError: OutputError = prepared.ok
      ? { code: 'UNKNOWN', message: 'Sanitized error output was unavailable' }
      : prepared.error
    const error =
      sanitized.output && typeof sanitized.output === 'object' && 'code' in sanitized.output
        ? (sanitized.output as OutputError)
        : {
            ...baseError,
            ...(warnings.length ? { warnings: [...new Set(warnings)] } : undefined),
          }

    return {
      ...prepared,
      error,
      meta: {
        ...prepared.meta,
        ...(warnings.length ? { warnings: [...new Set(warnings)] } : undefined),
      },
    }
  }

  async function write(output: Output, outputSchema?: z.ZodType | undefined) {
    output = await prepareOutput(output, outputSchema)
    const blocked = !output.ok && output.error.code === 'SANITIZED_OUTPUT_BLOCKED'
    const cta = output.meta.cta
    const warnings = output.meta.warnings
    if (tokenCount) {
      const base = output.ok ? withWarnings(output.data, warnings) : output.error
      const formatted = base != null ? Formatter.format(base, format) : ''
      writeln(String(estimateTokenCount(formatted)))
      if (blocked) exit(1)
      return
    }
    if (human && !verbose) {
      if (output.ok && output.data != null && renderOutput) {
        if (warnings) for (const warning of warnings) writeln(`Warning: ${warning}`)
        const t = truncate(Formatter.format(output.data, format))
        writeln(t.text)
      } else if (!output.ok) writeln(formatHumanError(output.error))
      if (cta) writeln(formatHumanCta(cta))
      if (blocked) exit(1)
      return
    }
    if (verbose) {
      if (tokenLimit != null || tokenOffset != null) {
        // Truncate data separately so meta (including nextOffset) is always visible
        const dataFormatted =
          output.ok && output.data != null
            ? Formatter.format(output.data, format)
            : !output.ok
              ? Formatter.format(output.error, format)
              : ''
        const t = truncate(dataFormatted)
        if (t.truncated) {
          const envelope: Record<string, unknown> = output.ok
            ? { ok: true, data: t.text }
            : { ok: false, error: t.text }
          const meta: Record<string, unknown> = { ...output.meta }
          if (t.nextOffset != null) meta.nextOffset = t.nextOffset
          envelope.meta = meta
          return writeln(Formatter.format(envelope, format))
        }
      }
      writeln(Formatter.format(output, format))
      if (blocked) exit(1)
      return
    }
    const base = output.ok ? withWarnings(output.data, warnings) : output.error
    const formatted = Formatter.format(base, format)
    if (!cta) {
      if (formatted) writeln(truncate(formatted).text)
      if (blocked) exit(1)
      return
    }
    const payload =
      typeof base === 'object' && base !== null ? { ...base, cta } : { data: base, cta }
    writeln(truncate(Formatter.format(payload, format)).text)
    if (blocked) exit(1)
  }

  if ('error' in effective) {
    const helpCmd = effective.path ? `${name} ${effective.path} --help` : `${name} --help`
    const parent = effective.path ? `${name} ${effective.path}` : name
    const message = `'${effective.error}' is not a command for '${parent}'.`
    const cta: FormattedCtaBlock = {
      description: 'See available commands:',
      commands: [{ command: helpCmd }],
    }
    if (human && !verbose) {
      writeln(formatHumanError({ code: 'COMMAND_NOT_FOUND', message }))
      writeln(formatHumanCta(cta))
      exit(1)
      return
    }
    await write({
      ok: false,
      error: { code: 'COMMAND_NOT_FOUND', message },
      meta: {
        command: effective.error,
        cta,
        duration: `${Math.round(performance.now() - start)}ms`,
      },
    })
    exit(1)
    return
  }

  // Fetch gateway execution path
  if ('fetchGateway' in effective) {
    const { fetchGateway, path, rest: fetchRest } = effective
    const fetchMiddleware = [
      ...(options.middlewares ?? []),
      ...((effective as any).middlewares ?? []),
    ]

    const runFetch = async () => {
      const input = Fetch.parseArgv(fetchRest)
      if (fetchGateway.basePath) input.path = fetchGateway.basePath + input.path
      const request = Fetch.buildRequest(input)
      const response = await fetchGateway.fetch(request)

      // Streaming path — NDJSON responses pipe through handleStreaming
      if (Fetch.isStreamingResponse(response)) {
        const generator = Fetch.parseStreamingResponse(response)
        await handleStreaming(generator, {
          name,
          path,
          start,
          format,
          formatExplicit,
          human,
          renderOutput,
          verbose,
          truncate,
          write,
          writeln,
          exit,
        })
        return
      }

      const output = await Fetch.parseResponse(response)

      if (output.ok) {
        await write({
          ok: true,
          data: output.data,
          meta: {
            command: path,
            duration: `${Math.round(performance.now() - start)}ms`,
          },
        })
      } else {
        await write({
          ok: false,
          error: {
            code: `HTTP_${output.status}`,
            message:
              typeof output.data === 'object' && output.data !== null && 'message' in output.data
                ? String((output.data as any).message)
                : typeof output.data === 'string'
                  ? output.data
                  : `HTTP ${output.status}`,
          },
          meta: {
            command: path,
            duration: `${Math.round(performance.now() - start)}ms`,
          },
        })
        exit(1)
      }
    }

    try {
      const cliEnv = options.envSchema
        ? Parser.parseEnv(options.envSchema, options.env ?? process.env)
        : {}
      if (fetchMiddleware.length > 0) {
        const varsMap: Record<string, unknown> = options.vars ? options.vars.parse({}) : {}
        const errorFn = (opts: {
          code: string
          exitCode?: number | undefined
          message: string
          retryable?: boolean | undefined
          cta?: CtaBlock | undefined
        }): never => ({ [sentinel]: 'error', ...opts }) as never
        const mwCtx: MiddlewareContext = {
          agent: !human,
          command: path,
          env: cliEnv,
          error: errorFn,
          format,
          formatExplicit,
          name,
          set(key: string, value: unknown) {
            varsMap[key] = value
          },
          var: varsMap,
          version: options.version,
        }
        const handleMwSentinel = async (result: unknown) => {
          if (!isSentinel(result) || result[sentinel] !== 'error') return
          const err = result as ErrorResult
          const cta = formatCtaBlock(name, err.cta)
          await write({
            ok: false,
            error: {
              code: err.code,
              message: err.message,
              ...(err.retryable !== undefined ? { retryable: err.retryable } : undefined),
            },
            meta: {
              command: path,
              duration: `${Math.round(performance.now() - start)}ms`,
              ...(cta ? { cta } : undefined),
            },
          })
          exit(err.exitCode ?? 1)
        }
        const composed = fetchMiddleware.reduceRight(
          (next: () => Promise<void>, mw) => async () => {
            await handleMwSentinel(await mw(mwCtx, next))
          },
          runFetch,
        )
        await composed()
      } else {
        await runFetch()
      }
    } catch (error) {
      await write({
        ok: false,
        error: {
          code: error instanceof IncurError ? error.code : 'UNKNOWN',
          message: error instanceof Error ? error.message : String(error),
        },
        meta: { command: path, duration: `${Math.round(performance.now() - start)}ms` },
      })
      exit(error instanceof IncurError ? (error.exitCode ?? 1) : 1)
    }
    return
  }

  const { command, path, rest } = effective

  // Collect middleware: root CLI + groups traversed + per-command
  const allMiddleware = [
    ...(options.middlewares ?? []),
    ...('middlewares' in resolved
      ? (((resolved as any).middlewares as MiddlewareHandler[]) ?? [])
      : []),
    ...((command.middleware as MiddlewareHandler[] | undefined) ?? []),
  ]

  // Initialize vars from schema defaults
  const varsMap: Record<string, unknown> = options.vars ? options.vars.parse({}) : {}
  const envSource = options.env ?? process.env

  const runCommand = async () => {
    const effectiveOptionsSchema = getEffectiveOptionsSchema(command)
    const { args, options: parsedOptions } = Parser.parse(rest, {
      alias: command.alias as Record<string, string> | undefined,
      args: command.args,
      options: effectiveOptionsSchema,
    })
    const { control, options: resolvedOptions } = resolveCommandOptions(
      command,
      parsedOptions as Record<string, unknown>,
    )

    if (human)
      emitDeprecationWarnings(
        rest,
        effectiveOptionsSchema,
        command.alias as Record<string, string> | undefined,
      )

    const env = command.env ? Parser.parseEnv(command.env, envSource) : {}

    if (control.dryRun) {
      await write({
        ok: true,
        data: {
          dryRun: true,
          command: path,
          args,
          options: resolvedOptions,
          env,
        },
        meta: {
          command: path,
          duration: `${Math.round(performance.now() - start)}ms`,
        },
      })
      return
    }

    const okFn = (data: unknown, meta: { cta?: CtaBlock | undefined } = {}): never => {
      return { [sentinel]: 'ok', data, cta: meta.cta } as never
    }
    const errorFn = (opts: {
      code: string
      exitCode?: number | undefined
      message: string
      retryable?: boolean | undefined
      cta?: CtaBlock | undefined
    }): never => {
      return { [sentinel]: 'error', ...opts } as never
    }

    const result = command.run({
      agent: !human,
      args,
      dryRun: control.dryRun,
      env,
      name,
      options: resolvedOptions,
      ok: okFn,
      error: errorFn,
      format,
      formatExplicit,
      var: varsMap,
      version: options.version,
    })

    // Streaming path — async generator
    if (isAsyncGenerator(result)) {
      await handleStreaming(result, {
        name,
        path,
        start,
        format,
        formatExplicit,
        human,
        renderOutput,
        verbose,
        truncate,
        write,
        writeln,
        exit,
      })
      return
    }

    const awaited = await result

    if (isSentinel(awaited)) {
      const cta = formatCtaBlock(name, awaited.cta)
      if (awaited[sentinel] === 'ok') {
        await write(
          {
            ok: true,
            data: awaited.data,
            meta: {
              command: path,
              duration: `${Math.round(performance.now() - start)}ms`,
              ...(cta ? { cta } : undefined),
            },
          },
          command.output,
        )
      } else {
        const err = awaited as ErrorResult
        await write({
          ok: false,
          error: {
            code: err.code,
            message: err.message,
            ...(err.retryable !== undefined ? { retryable: err.retryable } : undefined),
          },
          meta: {
            command: path,
            duration: `${Math.round(performance.now() - start)}ms`,
            ...(cta ? { cta } : undefined),
          },
        })
        exit(err.exitCode ?? 1)
      }
    } else {
      await write(
        {
          ok: true,
          data: awaited,
          meta: {
            command: path,
            duration: `${Math.round(performance.now() - start)}ms`,
          },
        },
        command.output,
      )
    }
  }

  try {
    const cliEnv = options.envSchema ? Parser.parseEnv(options.envSchema, envSource) : {}

    if (allMiddleware.length > 0) {
      const errorFn = (opts: {
        code: string
        exitCode?: number | undefined
        message: string
        retryable?: boolean | undefined
        cta?: CtaBlock | undefined
      }): never => {
        return { [sentinel]: 'error', ...opts } as never
      }
      const mwCtx: MiddlewareContext = {
        agent: !human,
        command: path,
        env: cliEnv,
        error: errorFn,
        format,
        formatExplicit,
        name,
        set(key: string, value: unknown) {
          varsMap[key] = value
        },
        var: varsMap,
        version: options.version,
      }
      const handleMwSentinel = async (result: unknown) => {
        if (!isSentinel(result) || result[sentinel] !== 'error') return
        const err = result as ErrorResult
        const cta = formatCtaBlock(name, err.cta)
        await write({
          ok: false,
          error: {
            code: err.code,
            message: err.message,
            ...(err.retryable !== undefined ? { retryable: err.retryable } : undefined),
          },
          meta: {
            command: path,
            duration: `${Math.round(performance.now() - start)}ms`,
            ...(cta ? { cta } : undefined),
          },
        })
        exit(err.exitCode ?? 1)
      }
      const composed = allMiddleware.reduceRight(
        (next: () => Promise<void>, mw) => async () => {
          await handleMwSentinel(await mw(mwCtx, next))
        },
        runCommand,
      )
      await composed()
    } else {
      await runCommand()
    }
  } catch (error) {
    const errorOutput: Output = {
      ok: false,
      error: {
        code:
          error instanceof IncurError
            ? error.code
            : error instanceof ValidationError
              ? 'VALIDATION_ERROR'
              : 'UNKNOWN',
        message: error instanceof Error ? error.message : String(error),
        ...(error instanceof IncurError ? { retryable: error.retryable } : undefined),
        ...(error instanceof ValidationError ? { fieldErrors: error.fieldErrors } : undefined),
      },
      meta: {
        command: path,
        duration: `${Math.round(performance.now() - start)}ms`,
      },
    }

    if (human && !formatExplicit && error instanceof ValidationError) {
      writeln(formatHumanValidationError(name, path, command, error, options.env))
      exit(1)
      return
    }

    await write(errorOutput)
    exit(error instanceof IncurError ? (error.exitCode ?? 1) : 1)
  }
}

/** @internal Options for fetchImpl. */
declare namespace fetchImpl {
  type Options = {
    envSchema?: z.ZodObject<any> | undefined
    mcpHandler?:
      | ((req: Request, commands: Map<string, CommandEntry>) => Promise<Response>)
      | undefined
    middlewares?: MiddlewareHandler[] | undefined
    rootCommand?: CommandDefinition<any, any, any> | undefined
    sanitize?:
      | ((
          output: unknown,
          context: { command: string; agent: boolean },
        ) => Promise<{
          output: unknown
          blocked: boolean
          warnings?: string[] | undefined
        }>)
      | undefined
    vars?: z.ZodObject<any> | undefined
    version?: string | undefined
  }
}

/** @internal Creates a lazy MCP HTTP handler scoped to a CLI instance. */
function createMcpHttpHandler(
  name: string,
  version: string,
  sanitize?:
    | ((
        output: unknown,
        context: { command: string; agent: boolean },
      ) => Promise<{
        output: unknown
        blocked: boolean
        warnings?: string[] | undefined
      }>)
    | undefined,
) {
  let transport: any

  return async (req: Request, commands: Map<string, CommandEntry>): Promise<Response> => {
    try {
      if (!transport) {
        const { McpServer } = await import('@modelcontextprotocol/sdk/server/mcp.js')
        const { WebStandardStreamableHTTPServerTransport } =
          await import('@modelcontextprotocol/sdk/server/webStandardStreamableHttp.js')

        const server = new McpServer({ name, version })

        for (const tool of Mcp.collectTools(commands, [])) {
          const optionsSchema = getEffectiveOptionsSchema(tool.command)
          const mergedShape: Record<string, any> = {
            ...tool.command.args?.shape,
            ...optionsSchema?.shape,
          }
          const hasInput = Object.keys(mergedShape).length > 0

          server.registerTool(
            tool.name,
            {
              ...(tool.description ? { description: tool.description } : undefined),
              ...(hasInput ? { inputSchema: mergedShape } : undefined),
            },
            async (...callArgs: any[]) => {
              const params = hasInput ? (callArgs[0] as Record<string, unknown>) : {}
              const extra = hasInput ? callArgs[1] : callArgs[0]
              return Mcp.callTool(tool, params, extra, sanitize)
            },
          )
        }

        transport = new WebStandardStreamableHTTPServerTransport({
          sessionIdGenerator: () => crypto.randomUUID(),
          enableJsonResponse: true,
        })
        await server.connect(transport)
      }
      return transport.handleRequest(req)
    } catch (error) {
      return renderPendingFetchError(name, error)
    }
  }
}

/** @internal Handles an HTTP request by resolving a command and returning a JSON Response. */
async function fetchImpl(
  name: string,
  commands: Map<string, CommandEntry>,
  req: Request,
  options: fetchImpl.Options = {},
): Promise<Response> {
  const start = performance.now()

  const url = new URL(req.url)
  const segments = url.pathname.split('/').filter(Boolean)

  // MCP over HTTP: route /mcp to the MCP transport
  if (segments[0] === 'mcp' && segments.length === 1 && options.mcpHandler)
    return options.mcpHandler(req, commands)

  // .well-known/skills/ — Agent Skills Discovery (RFC)
  if (
    segments[0] === '.well-known' &&
    segments[1] === 'skills' &&
    segments.length >= 3 &&
    req.method === 'GET'
  ) {
    const groups = new Map<string, string>()
    const cmds = collectSkillCommands(commands, [], groups)

    // GET /.well-known/skills/index.json
    if (segments[2] === 'index.json' && segments.length === 3) {
      const files = Skill.split(name, cmds, 1, groups)
      const skills = files.map((f) => {
        const descMatch = f.content.match(/^description:\s*(.+)$/m)
        return {
          name: f.dir || name,
          description: descMatch?.[1] ?? '',
          files: ['SKILL.md'],
        }
      })
      return new Response(JSON.stringify({ skills }), {
        status: 200,
        headers: { 'content-type': 'application/json', 'cache-control': 'public, max-age=300' },
      })
    }

    // GET /.well-known/skills/{skill-name}/SKILL.md
    if (segments.length === 4 && segments[3] === 'SKILL.md') {
      const skillName = segments[2]!
      const files = Skill.split(name, cmds, 1, groups)
      const file = files.find((f) => (f.dir || name) === skillName)
      if (file)
        return new Response(file.content, {
          status: 200,
          headers: { 'content-type': 'text/markdown', 'cache-control': 'public, max-age=300' },
        })
      return new Response('Not Found', { status: 404 })
    }

    return new Response('Not Found', { status: 404 })
  }

  // Parse options from search params (GET) or body (non-GET)
  let inputOptions: Record<string, unknown> = {}
  const inputArgv = req.method === 'GET' ? searchParamsToArgv(url.searchParams) : undefined
  if (req.method !== 'GET') {
    try {
      const contentType = req.headers.get('content-type') ?? ''
      if (contentType.includes('application/json'))
        inputOptions = (await req.json()) as Record<string, unknown>
    } catch {}
  }

  function jsonResponse(body: unknown, status: number) {
    return new Response(JSON.stringify(body), {
      status,
      headers: { 'content-type': 'application/json' },
    })
  }

  // Resolve command from path segments
  if (segments.length === 0) {
    // Root path
    if (options.rootCommand)
      return executeCommand(name, options.rootCommand, [], inputOptions, inputArgv, start, options)
    return jsonResponse(
      {
        ok: false,
        error: { code: 'COMMAND_NOT_FOUND', message: 'No root command defined.' },
        meta: { command: '/', duration: `${Math.round(performance.now() - start)}ms` },
      },
      404,
    )
  }

  const resolved = resolveCommand(commands, segments)

  if ('error' in resolved)
    return jsonResponse(
      {
        ok: false,
        error: {
          code: 'COMMAND_NOT_FOUND',
          message: `'${resolved.error}' is not a command for '${resolved.path ? `${name} ${resolved.path}` : name}'.`,
        },
        meta: { command: resolved.error, duration: `${Math.round(performance.now() - start)}ms` },
      },
      404,
    )

  if ('help' in resolved)
    return jsonResponse(
      {
        ok: false,
        error: {
          code: 'COMMAND_NOT_FOUND',
          message: `'${resolved.path}' is a command group. Specify a subcommand.`,
        },
        meta: { command: resolved.path, duration: `${Math.round(performance.now() - start)}ms` },
      },
      404,
    )

  if ('fetchGateway' in resolved)
    return executeFetchGateway(
      resolved.path,
      resolved.fetchGateway,
      req,
      start,
      options,
      resolved.middlewares,
    )

  const { command, path, rest } = resolved
  return executeCommand(path, command, rest, inputOptions, inputArgv, start, options, resolved.middlewares)
}

/** @internal Executes a resolved command for the fetch handler and returns a JSON Response. */
async function executeCommand(
  path: string,
  command: CommandDefinition<any, any, any>,
  rest: string[],
  inputOptions: Record<string, unknown>,
  inputArgv: string[] | undefined,
  start: number,
  options: fetchImpl.Options,
  middlewares: MiddlewareHandler[] = [],
): Promise<Response> {
  function jsonResponse(body: unknown, status: number) {
    return new Response(JSON.stringify(body), {
      status,
      headers: { 'content-type': 'application/json' },
    })
  }

  const sentinel_ = Symbol.for('incur.sentinel')
  const varsMap: Record<string, unknown> = options.vars ? options.vars.parse({}) : {}
  let response: Response | undefined
  let responsePromise: Promise<Response> | undefined

  async function responseFor(
    body:
      | { ok: true; data: unknown; meta: { command: string; duration: string } }
      | {
          ok: false
          error: { code: string; message: string; warnings?: string[] | undefined }
          meta: { command: string; duration: string; warnings?: string[] | undefined }
        },
    status: number,
  ) {
    const warnings = [...new Set(body.ok ? [] : (body.meta.warnings ?? []))]
    const target = body.ok ? body.data : body.error
    const sanitized = await Sanitize.sanitize(
      target,
      { command: path, agent: true },
      options.sanitize,
    )

    if (sanitized.warnings) warnings.push(...sanitized.warnings)

    if (sanitized.blocked)
      return jsonResponse(
        {
          ok: false,
          error: {
            code: 'SANITIZED_OUTPUT_BLOCKED',
            message: 'Command output was blocked by sanitization',
            ...(warnings.length ? { warnings: [...new Set(warnings)] } : undefined),
          },
          meta: {
            command: path,
            duration: body.meta.duration,
            ...(warnings.length ? { warnings: [...new Set(warnings)] } : undefined),
          },
        },
        500,
      )

    if (body.ok)
      return jsonResponse(
        {
          ...body,
          data: sanitized.output,
          meta: {
            ...body.meta,
            ...(warnings.length ? { warnings: [...new Set(warnings)] } : undefined),
          },
        },
        status,
      )

    const error =
      sanitized.output && typeof sanitized.output === 'object' && 'code' in sanitized.output
        ? sanitized.output
        : {
            ...body.error,
            ...(warnings.length ? { warnings: [...new Set(warnings)] } : undefined),
          }

    return jsonResponse(
      {
        ...body,
        error,
        meta: {
          ...body.meta,
          ...(warnings.length ? { warnings: [...new Set(warnings)] } : undefined),
        },
      },
      status,
    )
  }

  const runCommand = async () => {
    const effectiveOptionsSchema = getEffectiveOptionsSchema(command)
    const { args, options: parsedOptions } = inputArgv
      ? Parser.parse([...rest, ...inputArgv], {
          alias: command.alias as Record<string, string> | undefined,
          args: command.args,
          options: effectiveOptionsSchema,
        })
      : {
          args: Parser.parse(rest, { args: command.args }).args,
          options: effectiveOptionsSchema ? effectiveOptionsSchema.parse(inputOptions) : {},
        }
    const { control, options: resolvedOptions } = resolveCommandOptions(
      command,
      parsedOptions as Record<string, unknown>,
    )
    const envSource = process.env
    const env = command.env ? Parser.parseEnv(command.env, envSource) : {}

    if (control.dryRun) {
      response = await responseFor(
        {
          ok: true,
          data: {
            dryRun: true,
            command: path,
            args,
            options: resolvedOptions,
            env,
          },
          meta: { command: path, duration: `${Math.round(performance.now() - start)}ms` },
        },
        200,
      )
      return
    }

    const okFn = (data: unknown): never => ({ [sentinel_]: 'ok', data }) as never
    const errorFn = (opts: {
      code: string
      message: string
      exitCode?: number | undefined
    }): never => ({ [sentinel_]: 'error', ...opts }) as never

    const result = command.run({
      agent: true,
      args,
      dryRun: control.dryRun,
      env,
      error: errorFn,
      format: 'json',
      formatExplicit: true,
      name: path,
      ok: okFn,
      options: resolvedOptions,
      var: varsMap,
      version: options.version,
    })

    // Streaming path — async generator → NDJSON response
    if (isAsyncGenerator(result)) {
      const stream = new ReadableStream({
        async start(controller) {
          const encoder = new TextEncoder()
          try {
            let returnValue: unknown
            while (true) {
              const { value, done } = await result.next()
              if (done) {
                returnValue = value
                break
              }
              if (isSentinel(value) && (value as any)[sentinel] === 'error') {
                const tagged = value as any
                controller.enqueue(
                  encoder.encode(
                    JSON.stringify({
                      type: 'error',
                      ok: false,
                      error: { code: tagged.code, message: tagged.message },
                    }) + '\n',
                  ),
                )
                controller.close()
                return
              }
              controller.enqueue(
                encoder.encode(JSON.stringify({ type: 'chunk', data: value }) + '\n'),
              )
            }
            const meta: Record<string, unknown> = { command: path }
            if (isSentinel(returnValue) && (returnValue as any)[sentinel] === 'error') {
              const tagged = returnValue as any
              controller.enqueue(
                encoder.encode(
                  JSON.stringify({
                    type: 'error',
                    ok: false,
                    error: { code: tagged.code, message: tagged.message },
                  }) + '\n',
                ),
              )
            } else {
              controller.enqueue(
                encoder.encode(JSON.stringify({ type: 'done', ok: true, meta }) + '\n'),
              )
            }
          } catch (error) {
            controller.enqueue(
              encoder.encode(
                JSON.stringify({
                  type: 'error',
                  ok: false,
                  error: {
                    code: 'UNKNOWN',
                    message: error instanceof Error ? error.message : String(error),
                  },
                }) + '\n',
              ),
            )
          }
          controller.close()
        },
      })
      response = new Response(stream, {
        status: 200,
        headers: { 'content-type': 'application/x-ndjson' },
      })
      return
    }

    const awaited = await result
    const duration = `${Math.round(performance.now() - start)}ms`

    if (typeof awaited === 'object' && awaited !== null && sentinel_ in awaited) {
      const tagged = awaited as any
      if (tagged[sentinel_] === 'error')
        response = await responseFor(
          {
            ok: false,
            error: { code: tagged.code, message: tagged.message },
            meta: { command: path, duration },
          },
          500,
        )
      else
        response = await responseFor(
          { ok: true, data: tagged.data, meta: { command: path, duration } },
          200,
        )
      return
    }

    response = await responseFor(
      { ok: true, data: awaited, meta: { command: path, duration } },
      200,
    )
  }

  try {
    const envSource = process.env
    const allMiddleware = [
      ...(options.middlewares ?? []),
      ...middlewares,
      ...((command.middleware as MiddlewareHandler[] | undefined) ?? []),
    ]
    if (allMiddleware.length > 0) {
      const errorFn = (opts: {
        code: string
        message: string
        exitCode?: number | undefined
      }): never => {
        const duration = `${Math.round(performance.now() - start)}ms`
        responsePromise = responseFor(
          {
            ok: false,
            error: { code: opts.code, message: opts.message },
            meta: { command: path, duration },
          },
          500,
        )
        return undefined as never
      }
      const mwCtx: MiddlewareContext = {
        agent: true,
        command: path,
        env: options.envSchema ? Parser.parseEnv(options.envSchema, envSource) : {},
        error: errorFn,
        format: 'json',
        formatExplicit: true,
        name: path,
        set(key: string, value: unknown) {
          varsMap[key] = value
        },
        var: varsMap,
        version: options.version,
      }
      const composed = allMiddleware.reduceRight(
        (next: () => Promise<void>, mw) => async () => {
          await mw(mwCtx, next)
        },
        runCommand,
      )
      await composed()
    } else {
      await runCommand()
    }
  } catch (error) {
    const duration = `${Math.round(performance.now() - start)}ms`
    if (error instanceof ValidationError)
      return responseFor(
        {
          ok: false,
          error: { code: 'VALIDATION_ERROR', message: error.message },
          meta: { command: path, duration },
        },
        400,
      )
    return responseFor(
      {
        ok: false,
        error: {
          code: error instanceof IncurError ? error.code : 'UNKNOWN',
          message: error instanceof Error ? error.message : String(error),
        },
        meta: { command: path, duration },
      },
      500,
    )
  }

  if (!response && responsePromise) response = await responsePromise
  return response!
}

/** @internal Executes a resolved fetch gateway for the fetch handler and returns a Response. */
async function executeFetchGateway(
  path: string,
  fetchGateway: InternalFetchGateway,
  req: Request,
  start: number,
  options: fetchImpl.Options,
  middlewares: MiddlewareHandler[] = [],
): Promise<Response> {
  function jsonResponse(body: unknown, status: number) {
    return new Response(JSON.stringify(body), {
      status,
      headers: { 'content-type': 'application/json' },
    })
  }

  const varsMap: Record<string, unknown> = options.vars ? options.vars.parse({}) : {}
  let response: Response | undefined

  const runFetch = async () => {
    response = await fetchGateway.fetch(req)
  }

  try {
    const envSource = process.env
    const allMiddleware = [...(options.middlewares ?? []), ...middlewares]

    if (allMiddleware.length > 0) {
      const errorFn = (opts: {
        code: string
        exitCode?: number | undefined
        message: string
        retryable?: boolean | undefined
        cta?: CtaBlock | undefined
      }): never => {
        return { [sentinel]: 'error', ...opts } as never
      }
      const mwCtx: MiddlewareContext = {
        agent: true,
        command: path,
        env: options.envSchema ? Parser.parseEnv(options.envSchema, envSource) : {},
        error: errorFn,
        format: 'json',
        formatExplicit: true,
        name: path,
        set(key: string, value: unknown) {
          varsMap[key] = value
        },
        var: varsMap,
        version: options.version,
      }
      const handleMwSentinel = async (result: unknown) => {
        if (!isSentinel(result) || result[sentinel] !== 'error') return
        const err = result as ErrorResult
        response = jsonResponse(
          {
            ok: false,
            error: {
              code: err.code,
              message: err.message,
              ...(err.retryable !== undefined ? { retryable: err.retryable } : undefined),
            },
            meta: {
              command: path,
              duration: `${Math.round(performance.now() - start)}ms`,
            },
          },
          500,
        )
      }
      const composed = allMiddleware.reduceRight(
        (next: () => Promise<void>, mw) => async () => {
          await handleMwSentinel(await mw(mwCtx, next))
        },
        runFetch,
      )
      await composed()
    } else {
      await runFetch()
    }
  } catch (error) {
    const duration = `${Math.round(performance.now() - start)}ms`
    if (error instanceof ValidationError)
      return jsonResponse(
        {
          ok: false,
          error: { code: 'VALIDATION_ERROR', message: error.message },
          meta: { command: path, duration },
        },
        400,
      )
    return jsonResponse(
      {
        ok: false,
        error: {
          code: error instanceof IncurError ? error.code : 'UNKNOWN',
          message: error instanceof Error ? error.message : String(error),
        },
        meta: { command: path, duration },
      },
      500,
    )
  }

  return response!
}

/** @internal Formats a validation error for TTY with usage hint. */
function formatHumanValidationError(
  cli: string,
  path: string,
  command: CommandDefinition<any, any, any>,
  error: ValidationError,
  envSource?: Record<string, string | undefined>,
): string {
  const lines: string[] = []
  for (const fe of error.fieldErrors) lines.push(`Error: missing required argument <${fe.path}>`)
  lines.push('See below for usage.')
  lines.push('')
  lines.push(
    Help.formatCommand(path === cli ? cli : `${cli} ${path}`, {
      alias: command.alias as Record<string, string> | undefined,
      description: command.description,
      args: command.args,
      env: command.env,
      envSource,
      hint: command.hint,
      options: getEffectiveOptionsSchema(command),
      examples: formatExamples(command.examples),
      usage: command.usage,
    }),
  )
  return lines.join('\n')
}

/** @internal Resolves a command from the tree by walking tokens until a leaf is found. */
function resolveCommand(
  commands: Map<string, CommandEntry>,
  tokens: string[],
):
  | {
      command: CommandDefinition<any, any, any>
      middlewares: MiddlewareHandler[]
      outputPolicy?: OutputPolicy | undefined
      path: string
      rest: string[]
    }
  | {
      fetchGateway: InternalFetchGateway
      middlewares: MiddlewareHandler[]
      outputPolicy?: OutputPolicy | undefined
      path: string
      rest: string[]
    }
  | {
      help: true
      path: string
      description?: string | undefined
      commands: Map<string, CommandEntry>
    }
  | { error: string; path: string } {
  const [first, ...rest] = tokens

  if (!first || !commands.has(first)) return { error: first ?? '(none)', path: '' }

  let entry = commands.get(first)!
  const path = [first]
  let remaining = rest
  let inheritedOutputPolicy: OutputPolicy | undefined
  const collectedMiddlewares: MiddlewareHandler[] = []

  // Fetch gateway — all remaining tokens go to the fetch handler
  if (isFetchGateway(entry)) {
    const outputPolicy = entry.outputPolicy ?? inheritedOutputPolicy
    return {
      fetchGateway: entry,
      middlewares: collectedMiddlewares,
      path: path.join(' '),
      rest: remaining,
      ...(outputPolicy ? { outputPolicy } : undefined),
    }
  }

  while (isGroup(entry)) {
    if (entry.outputPolicy) inheritedOutputPolicy = entry.outputPolicy
    if (entry.middlewares) collectedMiddlewares.push(...entry.middlewares)
    const next = remaining[0]
    if (!next)
      return {
        help: true,
        path: path.join(' '),
        description: entry.description,
        commands: entry.commands,
      }

    const child = entry.commands.get(next)
    if (!child) {
      return { error: next, path: path.join(' ') }
    }

    path.push(next)
    remaining = remaining.slice(1)
    entry = child

    if (isFetchGateway(entry)) {
      const outputPolicy = entry.outputPolicy ?? inheritedOutputPolicy
      return {
        fetchGateway: entry,
        middlewares: collectedMiddlewares,
        path: path.join(' '),
        rest: remaining,
        ...(outputPolicy ? { outputPolicy } : undefined),
      }
    }
  }

  const outputPolicy = entry.outputPolicy ?? inheritedOutputPolicy
  return {
    command: entry,
    middlewares: collectedMiddlewares,
    path: path.join(' '),
    rest: remaining,
    ...(outputPolicy ? { outputPolicy } : undefined),
  }
}

/** @internal Converts GET query params into argv-style flags so HTTP uses CLI parsing/coercion. */
function searchParamsToArgv(searchParams: URLSearchParams): string[] {
  const argv: string[] = []
  for (const [key, value] of searchParams) {
    argv.push(`--${key}`)
    if (value.length > 0) argv.push(value)
  }
  return argv
}

/** @internal Options for serveImpl, extending public serve.Options with internal metadata. */
declare namespace serveImpl {
  type Options = serve.Options & {
    /** Alternative binary names for this CLI. */
    aliases?: string[] | undefined
    description?: string | undefined
    contextRules?: string[] | undefined
    /** CLI-level env schema. Parsed before middleware runs. */
    envSchema?: z.ZodObject<any> | undefined
    /** CLI-level default output format. */
    format?: Formatter.Format | undefined
    /** Middleware handlers registered on the root CLI. */
    middlewares?: MiddlewareHandler[] | undefined
    /** CLI-level default output policy. */
    outputPolicy?: OutputPolicy | undefined
    sanitize?:
      | ((
          output: unknown,
          context: { command: string; agent: boolean },
        ) => Promise<{
          output: unknown
          blocked: boolean
          warnings?: string[] | undefined
        }>)
      | undefined
    mcp?:
      | {
          agents?: string[] | undefined
          command?: string | undefined
        }
      | undefined
    /** Root command handler, invoked when no subcommand matches. */
    rootCommand?: CommandDefinition<any, any, any> | undefined
    /** Root fetch handler, invoked when no subcommand matches and no rootCommand is set. */
    rootFetch?: FetchHandler | undefined
    sync?:
      | {
          cwd?: string | undefined
          depth?: number | undefined
          include?: string[] | undefined
          suggestions?: string[] | undefined
        }
      | undefined
    /** Zod schema for middleware variables. */
    vars?: z.ZodObject<any> | undefined
    version?: string | undefined
  }
}

/** @internal Extracts built-in flags (--verbose, --format, --json, --llms, --help, --version) from argv. */
function extractBuiltinFlags(argv: string[]) {
  let verbose = false
  let llms = false
  let llmsFull = false
  let mcp = false
  let help = false
  let version = false
  let schema = false
  let format: Formatter.Format = 'toon'
  let formatExplicit = false
  let filterOutput: string | undefined
  let tokenLimit: number | undefined
  let tokenOffset: number | undefined
  let tokenCount = false
  const rest: string[] = []

  for (let i = 0; i < argv.length; i++) {
    const token = argv[i]!
    if (token === '--verbose') verbose = true
    else if (token === '--llms') llms = true
    else if (token === '--llms-full') llmsFull = true
    else if (token === '--mcp') mcp = true
    else if (token === '--help' || token === '-h') help = true
    else if (token === '--version') version = true
    else if (token === '--schema') schema = true
    else if (token === '--json') {
      const next = argv[i + 1]
      if (next !== undefined && !next.startsWith('-')) rest.push(token)
      else {
        format = 'json'
        formatExplicit = true
      }
    } else if (token === '--format' && argv[i + 1]) {
      format = argv[i + 1] as Formatter.Format
      formatExplicit = true
      i++
    } else if ((token === '--filter-output' || token === '--fields') && argv[i + 1]) {
      filterOutput = argv[i + 1]!
      i++
    } else if (token === '--token-limit' && argv[i + 1]) {
      tokenLimit = Number(argv[i + 1])
      i++
    } else if (token === '--token-offset' && argv[i + 1]) {
      tokenOffset = Number(argv[i + 1])
      i++
    } else if (token === '--token-count') tokenCount = true
    else rest.push(token)
  }

  return { verbose, format, formatExplicit, filterOutput, tokenLimit, tokenOffset, tokenCount, llms, llmsFull, mcp, help, version, schema, rest }
}

/** @internal Returns a command's effective option schema, including injected framework flags. */
export function getCommandOptionsSchema(command: CommandDefinition<any, any, any>) {
  return getEffectiveOptionsSchema(command)
}

/** @internal Collects immediate child commands/groups for help output. */
function collectHelpCommands(
  commands: Map<string, CommandEntry>,
): { name: string; description?: string | undefined }[] {
  const result: { name: string; description?: string | undefined }[] = []
  for (const [name, entry] of commands) {
    result.push({ name, description: entry.description })
  }
  return result.sort((a, b) => a.name.localeCompare(b.name))
}

/** @internal Formats help text for a fetch gateway command. */
function formatFetchHelp(name: string, description?: string): string {
  const lines: string[] = []
  if (description) lines.push(`${name} — ${description}`)
  else lines.push(name)
  lines.push('')
  lines.push(`Usage: ${name} <path> [options]`)
  lines.push('')
  lines.push('Path segments are joined into the request URL path.')
  lines.push('')
  lines.push('Options:')
  lines.push('  -X, --method <METHOD>     HTTP method (default: GET, POST if body present)')
  lines.push('  -H, --header "Key: Val"   Set a request header (repeatable)')
  lines.push('  -d, --data <json>          Request body (implies POST)')
  lines.push('      --body <json>          Request body (implies POST)')
  lines.push('  --<key> <value>            Query string parameter')
  return lines.join('\n')
}

/** Shape of the commands map accumulated through `.command()` chains. */
export type CommandsMap = Record<
  string,
  { args: Record<string, unknown>; options: Record<string, unknown> }
>

/** @internal Entry stored in a command map — either a leaf definition, a group, or a fetch gateway. */
export type CommandEntry = CommandDefinition<any, any, any> | InternalGroup | InternalFetchGateway

/** Controls when output data is displayed. `'all'` displays to both humans and agents. `'agent-only'` suppresses data output in human/TTY mode. */
export type OutputPolicy = 'agent-only' | 'all'

/** A standard Fetch API handler. */
type FetchHandler = (req: Request) => Response | Promise<Response>

/** @internal A command group's internal storage. */
export type InternalGroup = {
  _group: true
  description?: string | undefined
  middlewares?: MiddlewareHandler[] | undefined
  outputPolicy?: OutputPolicy | undefined
  commands: Map<string, CommandEntry>
}

/** @internal A fetch gateway entry. */
type InternalFetchGateway = {
  _fetch: true
  basePath?: string | undefined
  description?: string | undefined
  fetch: FetchHandler
  outputPolicy?: OutputPolicy | undefined
}

/** @internal Type guard for command groups. */
function isGroup(entry: CommandEntry): entry is InternalGroup {
  return '_group' in entry
}

/** @internal Type guard for fetch gateways. */
function isFetchGateway(entry: CommandEntry): entry is InternalFetchGateway {
  return '_fetch' in entry
}

/** @internal Maps CLI instances to their command maps. */
export const toCommands = new WeakMap<Cli, Map<string, CommandEntry>>()

/** @internal Maps CLI instances to pending async generator mounts. */
const toPending = new WeakMap<Cli, Promise<void>[]>()

/** @internal Maps CLI instances to their middleware arrays. */
const toMiddlewares = new WeakMap<Cli, MiddlewareHandler[]>()

/** @internal Maps root CLI instances to their command definitions. */
const toRootDefinition = new WeakMap<Root, CommandDefinition<any, any, any>>()

/** @internal Maps CLI instances to their output policy. */
const toOutputPolicy = new WeakMap<Cli, OutputPolicy>()

/** @internal Sentinel symbol for `ok()` and `error()` return values. */
const sentinel = Symbol.for('incur.sentinel')

/** @internal A tagged ok result returned by the `ok` context helper. */
type OkResult = {
  [sentinel]: 'ok'
  data: unknown
  cta?: CtaBlock | undefined
}

/** @internal A tagged error result returned by the `error` context helper. */
type ErrorResult = {
  [sentinel]: 'error'
  code: string
  message: string
  retryable?: boolean | undefined
  exitCode?: number | undefined
  cta?: CtaBlock | undefined
}

/** @internal A CTA block with a description and list of suggested commands. */
type CtaBlock<commands extends CommandsMap = Commands> = {
  /** Commands to suggest. */
  commands: Cta<commands>[]
  /** Human-readable label. Defaults to `"Suggested commands:"`. */
  description?: string | undefined
}

/** @internal Formats an error for human-readable TTY output. */
function formatHumanError(error: {
  code: string
  message: string
  fieldErrors?: FieldError[] | undefined
}): string {
  const prefix =
    error.code === 'UNKNOWN' || error.code === 'COMMAND_NOT_FOUND'
      ? 'Error'
      : `Error (${error.code})`
  let out = `${prefix}: ${error.message}`
  if (error.fieldErrors) for (const fe of error.fieldErrors) out += `\n  ${fe.path}: ${fe.message}`
  return out
}

/** @internal Formats a CTA block for human-readable TTY output. */
function formatHumanCta(cta: FormattedCtaBlock): string {
  const lines: string[] = ['', cta.description]
  for (const c of cta.commands) {
    const desc = c.description ? `  # ${c.description}` : ''
    lines.push(`  ${c.command}${desc}`)
  }
  return lines.join('\n')
}

/** @internal Type guard for sentinel results. */
function hasRequiredArgs(args: z.ZodObject<z.ZodRawShape>): boolean {
  return Object.values(args.shape).some((field) => field._zod.optout !== 'optional')
}

function isSentinel(value: unknown): value is OkResult | ErrorResult {
  return typeof value === 'object' && value !== null && sentinel in value
}

/** @internal Type guard for async generators returned by streaming `run` handlers. */
function isAsyncGenerator(value: unknown): value is AsyncGenerator<unknown, unknown, unknown> {
  return (
    typeof value === 'object' &&
    value !== null &&
    Symbol.asyncIterator in value &&
    typeof (value as any).next === 'function'
  )
}

/** @internal Handles streaming output from an async generator `run` handler. */
async function handleStreaming(
  generator: AsyncGenerator<unknown, unknown, unknown>,
  ctx: {
    name: string
    path: string
    start: number
    format: Formatter.Format
    formatExplicit: boolean
    human: boolean
    renderOutput: boolean
    verbose: boolean
    truncate: (s: string) => { text: string; truncated: boolean; nextOffset?: number | undefined }
    write: (output: Output, outputSchema?: z.ZodType | undefined) => Promise<void>
    writeln: (s: string) => void
    exit: (code: number) => void
  },
) {
  // Incremental: no explicit format (default toon), or explicit jsonl
  // Buffered: explicit json/yaml/toon/md
  const useJsonl = ctx.format === 'jsonl'
  const incremental = useJsonl || (!ctx.formatExplicit && ctx.format === 'toon')

  if (incremental) {
    // Incremental output: write each chunk as it arrives
    try {
      let returnValue: unknown
      while (true) {
        const { value, done } = await generator.next()
        if (done) {
          returnValue = value
          break
        }
        if (isSentinel(value)) {
          const tagged = value as any
          if (tagged[sentinel] === 'error') {
            if (useJsonl)
              ctx.writeln(
                JSON.stringify({
                  type: 'error',
                  ok: false,
                  error: {
                    code: tagged.code,
                    message: tagged.message,
                    ...(tagged.retryable !== undefined
                      ? { retryable: tagged.retryable }
                      : undefined),
                  },
                }),
              )
            else ctx.writeln(formatHumanError({ code: tagged.code, message: tagged.message }))
            ctx.exit(tagged.exitCode ?? 1)
            return
          }
        }
        if (useJsonl) ctx.writeln(JSON.stringify({ type: 'chunk', data: value }))
        else if (ctx.renderOutput)
          ctx.writeln(ctx.truncate(Formatter.format(value, ctx.format)).text)
      }

      // Handle return value — error() or ok() sentinel
      if (isSentinel(returnValue) && returnValue[sentinel] === 'error') {
        const err = returnValue as ErrorResult
        if (useJsonl)
          ctx.writeln(
            JSON.stringify({
              type: 'error',
              ok: false,
              error: {
                code: err.code,
                message: err.message,
                ...(err.retryable !== undefined ? { retryable: err.retryable } : undefined),
              },
            }),
          )
        else ctx.writeln(formatHumanError({ code: err.code, message: err.message }))
        ctx.exit(err.exitCode ?? 1)
        return
      }

      const cta =
        isSentinel(returnValue) && returnValue[sentinel] === 'ok'
          ? formatCtaBlock(ctx.name, (returnValue as OkResult).cta)
          : undefined

      if (useJsonl)
        ctx.writeln(
          JSON.stringify({
            type: 'done',
            ok: true,
            meta: {
              command: ctx.path,
              duration: `${Math.round(performance.now() - ctx.start)}ms`,
              ...(cta ? { cta } : undefined),
            },
          }),
        )
      else if (cta) ctx.writeln(formatHumanCta(cta))
    } catch (error) {
      if (useJsonl)
        ctx.writeln(
          JSON.stringify({
            type: 'error',
            ok: false,
            error: {
              code: error instanceof IncurError ? error.code : 'UNKNOWN',
              message: error instanceof Error ? error.message : String(error),
            },
          }),
        )
      else
        ctx.writeln(
          formatHumanError({
            code: 'UNKNOWN',
            message: error instanceof Error ? error.message : String(error),
          }),
        )
      ctx.exit(error instanceof IncurError ? (error.exitCode ?? 1) : 1)
    }
  } else {
    // Buffered output: collect all chunks, write as single value
    const chunks: unknown[] = []
    try {
      let returnValue: unknown
      while (true) {
        const { value, done } = await generator.next()
        if (done) {
          returnValue = value
          break
        }
        if (isSentinel(value)) {
          const tagged = value as any
          if (tagged[sentinel] === 'error') {
            await ctx.write({
              ok: false,
              error: {
                code: tagged.code,
                message: tagged.message,
                ...(tagged.retryable !== undefined ? { retryable: tagged.retryable } : undefined),
              },
              meta: {
                command: ctx.path,
                duration: `${Math.round(performance.now() - ctx.start)}ms`,
              },
            })
            ctx.exit(tagged.exitCode ?? 1)
            return
          }
        }
        chunks.push(value)
      }

      if (isSentinel(returnValue) && returnValue[sentinel] === 'error') {
        const err = returnValue as ErrorResult
        await ctx.write({
          ok: false,
          error: {
            code: err.code,
            message: err.message,
            ...(err.retryable !== undefined ? { retryable: err.retryable } : undefined),
          },
          meta: {
            command: ctx.path,
            duration: `${Math.round(performance.now() - ctx.start)}ms`,
          },
        })
        ctx.exit(err.exitCode ?? 1)
        return
      }

      const cta =
        isSentinel(returnValue) && returnValue[sentinel] === 'ok'
          ? formatCtaBlock(ctx.name, (returnValue as OkResult).cta)
          : undefined

      await ctx.write({
        ok: true,
        data: chunks,
        meta: {
          command: ctx.path,
          duration: `${Math.round(performance.now() - ctx.start)}ms`,
          ...(cta ? { cta } : undefined),
        },
      })
    } catch (error) {
      await ctx.write({
        ok: false,
        error: {
          code: error instanceof IncurError ? error.code : 'UNKNOWN',
          message: error instanceof Error ? error.message : String(error),
        },
        meta: {
          command: ctx.path,
          duration: `${Math.round(performance.now() - ctx.start)}ms`,
        },
      })
      ctx.exit(error instanceof IncurError ? (error.exitCode ?? 1) : 1)
    }
  }
}

/** @internal Formats a CTA block into the output envelope shape. */
function formatCtaBlock(name: string, block: CtaBlock | undefined): FormattedCtaBlock | undefined {
  if (!block || block.commands.length === 0) return undefined
  return {
    description: block.description ?? 'Suggested commands:',
    commands: block.commands.map((c) => formatCta(name, c)),
  }
}

/** @internal Formats a CTA by prefixing the CLI name. Handles string and object forms. */
function formatCta(name: string, cta: Cta): FormattedCta {
  if (typeof cta === 'string') return { command: `${name} ${cta}` }
  const prefix = cta.command === name || cta.command.startsWith(`${name} `) ? '' : `${name} `
  let cmd = `${prefix}${cta.command}`
  if (cta.args)
    for (const [key, value] of Object.entries(cta.args))
      cmd += value === true ? ` <${key}>` : ` ${value}`
  if (cta.options)
    for (const [key, value] of Object.entries(cta.options))
      cmd += value === true ? ` --${key} <${key}>` : ` --${key} ${value}`
  return { command: cmd, ...(cta.description ? { description: cta.description } : undefined) }
}

/** @internal Builds the `--llms` index manifest (name + description only) from the command tree. */
function buildIndexManifest(commands: Map<string, CommandEntry>, prefix: string[] = []) {
  return {
    version: 'incur.v1',
    commands: collectIndexCommands(commands, prefix).sort((a, b) => a.name.localeCompare(b.name)),
  }
}

/** @internal Recursively collects leaf commands with name + description only. */
function collectIndexCommands(
  commands: Map<string, CommandEntry>,
  prefix: string[],
): { name: string; description?: string | undefined }[] {
  const result: { name: string; description?: string | undefined }[] = []
  for (const [name, entry] of commands) {
    const path = [...prefix, name]
    if (isGroup(entry)) {
      result.push(...collectIndexCommands(entry.commands, path))
    } else {
      const cmd: (typeof result)[number] = { name: path.join(' ') }
      if (isFetchGateway(entry)) {
        if (entry.description) cmd.description = entry.description
      } else if (entry.description) cmd.description = entry.description
      result.push(cmd)
    }
  }
  return result
}

/** @internal Builds the `--llms` manifest from the command tree. */
function buildManifest(commands: Map<string, CommandEntry>, prefix: string[] = []) {
  return {
    version: 'incur.v1',
    commands: collectCommands(commands, prefix).sort((a, b) => a.name.localeCompare(b.name)),
  }
}

/** @internal Recursively collects leaf commands with their full paths. */
function collectCommands(
  commands: Map<string, CommandEntry>,
  prefix: string[],
): {
  name: string
  description?: string | undefined
  schema?: Record<string, unknown> | undefined
  examples?: { command: string; description?: string | undefined }[] | undefined
  mutates?: boolean | undefined
  destructive?: boolean | undefined
  paginate?: boolean | undefined
  extensions?: Record<string, unknown> | undefined
  openapi?: Record<string, unknown> | undefined
}[] {
  const result: ReturnType<typeof collectCommands> = []
  for (const [name, entry] of commands) {
    const path = [...prefix, name]
    if (isFetchGateway(entry)) {
      const cmd: (typeof result)[number] = { name: path.join(' ') }
      if (entry.description) cmd.description = entry.description
      result.push(cmd)
    } else if (isGroup(entry)) {
      result.push(...collectCommands(entry.commands, path))
    } else result.push(describeCommand(path, entry))
  }
  return result
}

function describeCommand(
  path: string[],
  entry: CommandDefinition<any, any, any>,
): {
  name: string
  description?: string | undefined
  schema?: Record<string, unknown> | undefined
  examples?: { command: string; description?: string | undefined }[] | undefined
  mutates?: boolean | undefined
  destructive?: boolean | undefined
  paginate?: boolean | undefined
  extensions?: Record<string, unknown> | undefined
  openapi?: Record<string, unknown> | undefined
} {
  const cmd: ReturnType<typeof collectCommands>[number] = { name: path.join(' ') }
  if (entry.description) cmd.description = entry.description
  if (entry.mutates) cmd.mutates = true
  if (entry.destructive) cmd.destructive = true
  if (entry.paginate) cmd.paginate = true
  if (entry.extensions) cmd.extensions = entry.extensions
  if (entry.openapi) cmd.openapi = entry.openapi as Record<string, unknown>

  const inputSchema = buildInputSchema(
    entry.args,
    entry.env,
    getEffectiveOptionsSchema(entry),
    entry.input,
    entry.body,
  )
  const outputSchema = (() => {
    if (entry.output) {
      const json = Schema.toJsonSchema(entry.output)
      const properties = (json.properties as Record<string, unknown> | undefined) ?? {}
      if (Object.keys(properties).length > 0 || !entry.openapi?.response) return json
    }
    return entry.openapi?.response
  })()
  if (inputSchema || outputSchema) {
    cmd.schema = {}
    if (inputSchema?.args) cmd.schema.args = inputSchema.args
    if (inputSchema?.env) cmd.schema.env = inputSchema.env
    if (inputSchema?.options) cmd.schema.options = inputSchema.options
    if (inputSchema?.input) cmd.schema.input = inputSchema.input
    if (inputSchema?.body) cmd.schema.body = inputSchema.body
    if (outputSchema) cmd.schema.output = outputSchema
  }

  const examples = formatExamples(entry.examples)
  if (examples) {
    const cmdName = path.join(' ')
    cmd.examples = examples.map((e) => ({
      ...e,
      command: e.command ? `${cmdName} ${e.command}` : cmdName,
    }))
  }

  return cmd
}

/** @internal Recursively collects leaf commands as `Skill.CommandInfo` for `--llms --format md`. */
function collectSkillCommands(
  commands: Map<string, CommandEntry>,
  prefix: string[],
  groups: Map<string, string>,
): Skill.CommandInfo[] {
  const result: Skill.CommandInfo[] = []
  for (const [name, entry] of commands) {
    const path = [...prefix, name]
    if (isFetchGateway(entry)) {
      const cmd: Skill.CommandInfo = { name: path.join(' ') }
      if (entry.description) cmd.description = entry.description
      cmd.hint = 'Fetch gateway. Pass path segments and curl-style flags (-X, -H, -d, --key value).'
      result.push(cmd)
    } else if (isGroup(entry)) {
      if (entry.description) groups.set(path.join(' '), entry.description)
      result.push(...collectSkillCommands(entry.commands, path, groups))
    } else {
      const cmd: Skill.CommandInfo = { name: path.join(' ') }
      if (entry.description) cmd.description = entry.description
      if (entry.args) cmd.args = entry.args
      if (entry.env) cmd.env = entry.env
      if (entry.hint) cmd.hint = entry.hint
      const effectiveOptions = getEffectiveOptionsSchema(entry)
      if (effectiveOptions) cmd.options = effectiveOptions
      if (entry.output) cmd.output = entry.output
      if (entry.mutates)
        cmd.hint = [cmd.hint, 'Use `--dry-run` before executing this mutating command.']
          .filter(Boolean)
          .join(' ')
      if (entry.destructive)
        cmd.hint = [cmd.hint, 'Confirm with the user before executing this destructive command.']
          .filter(Boolean)
          .join(' ')
      const examples = formatExamples(entry.examples)
      if (examples) {
        const cmdName = path.join(' ')
        cmd.examples = examples.map((e) => ({
          ...e,
          command: e.command ? `${cmdName} ${e.command}` : cmdName,
        }))
      }
      result.push(cmd)
    }
  }
  return result.sort((a, b) => a.name.localeCompare(b.name))
}

/** @internal Formats examples into `{ command, description }` objects. `command` is the args/options suffix only. */
export function formatExamples(
  examples: Example<any, any>[] | undefined,
): { command: string; description?: string }[] | undefined {
  if (!examples || examples.length === 0) return undefined
  return examples.map((ex) => {
    const parts: string[] = []
    if (ex.args) for (const value of Object.values(ex.args)) parts.push(String(value))
    if (ex.options)
      for (const [key, value] of Object.entries(ex.options)) parts.push(`--${key} ${value}`)
    const result: { command: string; description?: string } = { command: parts.join(' ') }
    if (ex.description) result.description = ex.description
    return result
  })
}

/** @internal Builds separate args, env, and options JSON Schemas. */
function buildInputSchema(
  args: z.ZodObject<any> | undefined,
  env: z.ZodObject<any> | undefined,
  options: z.ZodObject<any> | undefined,
  input: z.ZodObject<any> | undefined,
  body: z.ZodObject<any> | undefined,
):
  | {
      args?: Record<string, unknown> | undefined
      env?: Record<string, unknown> | undefined
      options?: Record<string, unknown> | undefined
      input?: Record<string, unknown> | undefined
      body?: Record<string, unknown> | undefined
    }
  | undefined {
  if (!args && !env && !options && !input && !body) return undefined
  const result: {
    args?: Record<string, unknown> | undefined
    env?: Record<string, unknown> | undefined
    options?: Record<string, unknown> | undefined
    input?: Record<string, unknown> | undefined
    body?: Record<string, unknown> | undefined
  } = {}
  if (args) result.args = Schema.toJsonSchema(args)
  if (env) result.env = Schema.toJsonSchema(env)
  if (options) result.options = Schema.toJsonSchema(options)
  if (input) result.input = Schema.toJsonSchema(input)
  if (body) result.body = Schema.toJsonSchema(body)
  return result
}

/** @internal A usage example for a command, typed against its args and options schemas. */
type Example<
  args extends z.ZodObject<any> | undefined,
  options extends z.ZodObject<any> | undefined,
> = {
  /** Positional arguments for this example. */
  args?: args extends z.ZodObject<any> ? Partial<z.output<args>> | undefined : undefined
  /** A short description of what this example demonstrates. */
  description?: string | undefined
  /** Named options for this example. */
  options?: options extends z.ZodObject<any> ? Partial<z.output<options>> | undefined : undefined
}

/** @internal A usage pattern shown in help output. */
type Usage<
  args extends z.ZodObject<any> | undefined,
  options extends z.ZodObject<any> | undefined,
> = {
  /** Positional arguments to include. Use `true` to show as `<name>`. */
  args?: args extends z.ZodObject<any>
    ? Partial<Record<keyof z.output<args>, true>> | undefined
    : undefined
  /** Named options to include. Use `true` to show as `--name <name>`. */
  options?: options extends z.ZodObject<any>
    ? Partial<Record<keyof z.output<options>, true>> | undefined
    : undefined
  /** Text prepended before the command (e.g. `"cat file.txt |"`). */
  prefix?: string | undefined
  /** Text appended after the command (e.g. `"| head"`). */
  suffix?: string | undefined
}

/** @internal Inferred output type of a Zod schema, or `{}` when the schema is not provided. */
type InferOutput<schema extends z.ZodObject<any> | undefined> =
  schema extends z.ZodObject<any> ? z.output<schema> : {}

/** @internal Inferred return type for a command handler. */
type InferReturn<output extends z.ZodType | undefined> = output extends z.ZodType
  ? z.output<output>
  : unknown

/** @internal Inferred vars type from a Zod schema, or `{}` when no schema is provided. */
type InferVars<vars extends z.ZodObject<any> | undefined> =
  vars extends z.ZodObject<any> ? z.output<vars> : {}

/** @internal The output envelope written to stdout. */
type Output = OneOf<
  | {
      /** The command's return data. */
      data: unknown
      /** Request metadata. */
      meta: Output.Meta
      /** Whether the command succeeded. */
      ok: true
    }
  | {
      /** Error details. */
      error: {
        /** Machine-readable error code. */
        code: string
        /** Per-field validation errors. */
        fieldErrors?: FieldError[] | undefined
        /** Human-readable error message. */
        message: string
        /** Whether the operation can be retried. */
        retryable?: boolean | undefined
        /** Non-fatal warnings related to the output. */
        warnings?: string[] | undefined
      }
      /** Request metadata. */
      meta: Output.Meta
      /** Whether the command succeeded. */
      ok: false
    }
>

type OutputError = Extract<Output, { ok: false }>['error']

/** @internal */
declare namespace Output {
  /** Shared metadata included in every envelope. */
  type Meta = {
    /** The command that was invoked. */
    command: string
    /** Suggested next commands. */
    cta?: FormattedCtaBlock | undefined
    /** Wall-clock duration of the command. */
    duration: string
    /** Offset to pass as `--token-offset` to fetch the next page of truncated output. */
    nextOffset?: number | undefined
    /** Non-fatal warnings related to the output. */
    warnings?: string[] | undefined
  }
}

/** @internal Defines a command's schema, handler, and metadata. */
export type CommandDefinition<
  args extends z.ZodObject<any> | undefined = undefined,
  env extends z.ZodObject<any> | undefined = undefined,
  options extends z.ZodObject<any> | undefined = undefined,
  output extends z.ZodType | undefined = undefined,
  vars extends z.ZodObject<any> | undefined = undefined,
  cliEnv extends z.ZodObject<any> | undefined = undefined,
> = {
  /** Map of option names to single-char aliases. */
  alias?: options extends z.ZodObject<any>
    ? Partial<Record<keyof z.output<options>, string>>
    : Record<string, string> | undefined
  /** Zod schema for positional arguments. */
  args?: args | undefined
  /** Validates a full JSON payload passed via `--json`. */
  input?: z.ZodObject<any> | undefined
  /** Validates a request body passed via `--json`. */
  body?: z.ZodObject<any> | undefined
  /** A short description of what the command does. */
  description?: string | undefined
  /** Whether this command mutates external state. */
  mutates?: boolean | undefined
  /** Whether this command is destructive and requires confirmation. */
  destructive?: boolean | undefined
  /** Whether this command supports pagination helpers. */
  paginate?: boolean | undefined
  /** Zod schema for environment variables. Keys are the variable names (e.g. `NPM_TOKEN`). */
  env?: env | undefined
  /** Usage examples for this command. */
  examples?: Example<args, options>[] | undefined
  /** Generator-specific metadata that should flow through runtime introspection. */
  extensions?: Record<string, unknown> | undefined
  /** Default output format. Overridden by `--format` or `--json`. */
  format?: Formatter.Format | undefined
  /** Plain text hint displayed after examples and before global options. */
  hint?: string | undefined
  /** Runtime OpenAPI metadata for generated commands. */
  openapi?:
    | {
        description?: string | undefined
        httpMethod: string
        operationId?: string | undefined
        parameters?: {
          path?: Record<string, unknown> | undefined
          query?: Record<string, unknown> | undefined
        }
        path: string
        requestBody?: Record<string, unknown> | undefined
        response?: Record<string, unknown> | undefined
      }
    | undefined
  /** Zod schema for named options/flags. */
  options?: options | undefined
  /** Zod schema for the command's return value. */
  output?: output | undefined
  /**
   * Controls when output data is displayed. Inherited by child commands when set on a group.
   *
   * - `'all'` — displays to both humans and agents.
   * - `'agent-only'` — suppresses data output in human/TTY mode while still returning it to agents.
   *
   * @default 'all'
   */
  outputPolicy?: OutputPolicy | undefined
  /** Middleware that runs only for this command, after root and group middleware. */
  middleware?: MiddlewareHandler<vars, cliEnv>[] | undefined
  /** Alternative usage patterns shown in help output. */
  usage?: Usage<args, options>[] | undefined
  /** The command handler. Return a value for single-return, or use `async *run` to stream chunks. */
  run(context: {
    /** Whether the consumer is an agent (stdout is not a TTY). */
    agent: boolean
    /** Positional arguments. */
    args: InferOutput<args>
    /** The CLI name. */
    name: string
    /** Whether this invocation is a dry-run preflight. */
    dryRun: boolean
    /** Parsed environment variables. */
    env: InferOutput<env>
    /** Return an error result with optional CTAs. */
    error: (options: {
      code: string
      cta?: CtaBlock | undefined
      exitCode?: number | undefined
      message: string
      retryable?: boolean | undefined
    }) => never
    /** The resolved output format (e.g. `'toon'`, `'json'`, `'jsonl'`). */
    format: Formatter.Format
    /** Whether the user explicitly passed `--format` or `--json`. */
    formatExplicit: boolean
    /** Return a success result with optional metadata (e.g. CTAs). */
    ok: (data: InferReturn<output>, meta?: { cta?: CtaBlock | undefined }) => never
    options: InferOutput<options>
    /** Variables set by middleware. */
    var: InferVars<vars>
    /** The CLI version string. */
    version: string | undefined
  }):
    | InferReturn<output>
    | Promise<InferReturn<output>>
    | AsyncGenerator<InferReturn<output>, unknown, unknown>
}

/** @internal A formatted CTA block as it appears in the output envelope. */
type FormattedCtaBlock = {
  /** Formatted command suggestions. */
  commands: FormattedCta[]
  /** Human-readable label for the CTA block. */
  description: string
}

/** @internal A formatted CTA as it appears in the output envelope. */
type FormattedCta = {
  /** The full command string with args and options folded in. */
  command: string
  /** A short description of what the command does. */
  description?: string | undefined
}

/** @internal Scans argv for deprecated flags and writes warnings to stderr. */
function emitDeprecationWarnings(
  argv: string[],
  optionsSchema: z.ZodObject<any> | undefined,
  alias?: Record<string, string> | undefined,
) {
  if (!optionsSchema) return
  const shape = optionsSchema.shape as Record<string, any>
  const deprecatedFlags = new Set<string>()
  const deprecatedShorts = new Map<string, string>()
  for (const key of Object.keys(shape)) {
    const meta = shape[key]?.meta?.()
    if (meta?.deprecated) {
      const kebab = key.replace(/[A-Z]/g, (c: string) => `-${c.toLowerCase()}`)
      deprecatedFlags.add(kebab)
      if (alias?.[key]) deprecatedShorts.set(alias[key]!, kebab)
    }
  }
  if (deprecatedFlags.size === 0) return
  for (const token of argv) {
    if (token.startsWith('--')) {
      const stripped = token.split('=')[0]!.slice(2)
      const raw =
        !deprecatedFlags.has(stripped) && stripped.startsWith('no-') ? stripped.slice(3) : stripped
      if (deprecatedFlags.has(raw)) process.stderr.write(`Warning: --${raw} is deprecated\n`)
    } else if (token.startsWith('-') && token.length >= 2) {
      for (const ch of token.slice(1))
        if (deprecatedShorts.has(ch))
          process.stderr.write(`Warning: --${deprecatedShorts.get(ch)} is deprecated\n`)
    }
  }
}
